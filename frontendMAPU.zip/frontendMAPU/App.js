import React from 'react';
import { StatusBar } from 'expo-status-bar';
import { Provider as PaperProvider } from 'react-native-paper';
import { AuthProvider } from './src/contexts/AuthContext';
import { ToastProvider, useToast } from './src/contexts/ToastContext';
import AppNavigator from './src/AppNavigator';
import Toast from './src/components/Toast';
import { COLORS } from './src/utils/constants';

const AppContent = () => {
  const { toast } = useToast();

  return (
    <>
      <AppNavigator />
      <Toast
        visible={toast.visible}
        message={toast.message}
        type={toast.type}
        duration={toast.duration}
      />
    </>
  );
};

const theme = {
  colors: {
    primary: COLORS.primary,
    secondary: COLORS.secondary,
    surface: COLORS.white,
    background: COLORS.light,
    text: COLORS.textPrimary,
    placeholder: COLORS.textSecondary,
    disabled: COLORS.textSecondary,
  },
};

const AppWithProviders = () => {
  return (
    <ToastProvider>
      <AuthProvider>
        <AppContent />
      </AuthProvider>
    </ToastProvider>
  );
};

export default function App() {
  return (
    <PaperProvider theme={theme}>
      <AppWithProviders />
      <StatusBar style="auto" backgroundColor={COLORS.primary} />
    </PaperProvider>
  );
}
