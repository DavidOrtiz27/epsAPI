import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { useAuth } from './contexts/AuthContext';
import { COLORS, ROLES } from './utils/constants';

// Auth Screens
import LoginScreen from './screens/auth/LoginScreen';
import RegisterScreen from './screens/auth/RegisterScreen';

// Main Screens
import HomeScreen from './screens/HomeScreen';

// Patient Screens
import PatientProfileScreen from './screens/patient/PatientProfileScreen';
import PatientAppointmentsScreen from './screens/patient/PatientAppointmentsScreen';
import PatientMedicalHistoryScreen from './screens/patient/PatientMedicalHistoryScreen';
import PatientBillsScreen from './screens/patient/PatientBillsScreen';
import PatientSettingsScreen from './screens/patient/PatientSettingsScreen';

import DoctorPatientsScreen from './screens/doctor/DoctorPatientsScreen';
import DoctorAppointmentsScreen from './screens/doctor/DoctorAppointmentsScreen';
import DoctorMedicalRecordsScreen from './screens/doctor/DoctorMedicalRecordsScreen';
import DoctorPrescriptionsScreen from './screens/doctor/DoctorPrescriptionsScreen';

import AdminDashboardScreen from './screens/admin/AdminDashboardScreen';
import AdminUserManagementScreen from './screens/admin/AdminUserManagementScreen';
import AdminCRUDOperationsScreen from './screens/admin/AdminCRUDOperationsScreen';

const Stack = createStackNavigator();
const Tab = createBottomTabNavigator();

const AuthNavigator = () => (
  <Stack.Navigator
    screenOptions={{
      headerStyle: { backgroundColor: COLORS.primary },
      headerTintColor: COLORS.white,
      headerTitleStyle: { fontWeight: 'bold' },
    }}
  >
    <Stack.Screen
      name="Login"
      component={LoginScreen}
      options={{ title: 'Iniciar Sesión' }}
    />
    <Stack.Screen
      name="Register"
      component={RegisterScreen}
      options={{ title: 'Registrarse' }}
    />
  </Stack.Navigator>
);

const MainNavigator = () => {
  const { user } = useAuth();
  const userRole = user?.roles?.[0]?.name;

  // Role-based navigation
  if (userRole === ROLES.PACIENTE) {
    return (
      <Tab.Navigator
        screenOptions={{
          tabBarActiveTintColor: COLORS.primary,
          tabBarInactiveTintColor: COLORS.textSecondary,
          tabBarStyle: { backgroundColor: COLORS.white },
          headerStyle: { backgroundColor: COLORS.primary },
          headerTintColor: COLORS.white,
          headerTitleStyle: { fontWeight: 'bold' },
        }}
      >
        <Tab.Screen
          name="Appointments"
          component={PatientAppointmentsScreen}
          options={{
            title: 'Mis Citas',
            tabBarLabel: 'Citas',
          }}
        />
        <Tab.Screen
          name="MedicalHistory"
          component={PatientMedicalHistoryScreen}
          options={{
            title: 'Historial Médico',
            tabBarLabel: 'Historial',
          }}
        />
        <Tab.Screen
          name="Bills"
          component={PatientBillsScreen}
          options={{
            title: 'Mis Facturas',
            tabBarLabel: 'Facturas',
          }}
        />
        <Tab.Screen
          name="Profile"
          component={PatientProfileScreen}
          options={{
            title: 'Mi Perfil',
            tabBarLabel: 'Perfil',
          }}
        />
        <Tab.Screen
          name="Settings"
          component={PatientSettingsScreen}
          options={{
            title: 'Configuración',
            tabBarLabel: 'Ajustes',
          }}
        />
      </Tab.Navigator>
    );
  }

  if (userRole === ROLES.DOCTOR) {
    return (
      <Tab.Navigator
        screenOptions={{
          tabBarActiveTintColor: COLORS.primary,
          tabBarInactiveTintColor: COLORS.textSecondary,
          tabBarStyle: { backgroundColor: COLORS.white },
          headerStyle: { backgroundColor: COLORS.primary },
          headerTintColor: COLORS.white,
          headerTitleStyle: { fontWeight: 'bold' },
        }}
      >
        <Tab.Screen
          name="Home"
          component={HomeScreen}
          options={{
            title: 'Inicio',
            tabBarLabel: 'Inicio',
          }}
        />
        <Tab.Screen
          name="Patients"
          component={DoctorPatientsScreen}
          options={{
            title: 'Pacientes',
            tabBarLabel: 'Pacientes',
          }}
        />
        <Tab.Screen
          name="DoctorAppointments"
          component={DoctorAppointmentsScreen}
          options={{
            title: 'Citas',
            tabBarLabel: 'Citas',
          }}
        />
        <Tab.Screen
          name="MedicalRecords"
          component={DoctorMedicalRecordsScreen}
          options={{
            title: 'Registros',
            tabBarLabel: 'Registros',
          }}
        />
        <Tab.Screen
          name="Prescriptions"
          component={DoctorPrescriptionsScreen}
          options={{
            title: 'Recetas',
            tabBarLabel: 'Recetas',
          }}
        />
      </Tab.Navigator>
    );
  }

  if (userRole === ROLES.ADMIN || userRole === ROLES.SUPERADMIN) {
    return (
      <Tab.Navigator
        screenOptions={{
          tabBarActiveTintColor: COLORS.primary,
          tabBarInactiveTintColor: COLORS.textSecondary,
          tabBarStyle: { backgroundColor: COLORS.white },
          headerStyle: { backgroundColor: COLORS.primary },
          headerTintColor: COLORS.white,
          headerTitleStyle: { fontWeight: 'bold' },
        }}
      >
        <Tab.Screen
          name="Dashboard"
          component={AdminDashboardScreen}
          options={{
            title: 'Panel',
            tabBarLabel: 'Panel',
          }}
        />
        <Tab.Screen
          name="UserManagement"
          component={AdminUserManagementScreen}
          options={{
            title: 'Usuarios',
            tabBarLabel: 'Usuarios',
          }}
        />
        <Tab.Screen
          name="CRUDOperations"
          component={AdminCRUDOperationsScreen}
          options={{
            title: 'Operaciones',
            tabBarLabel: 'Operaciones',
          }}
        />
      </Tab.Navigator>
    );
  }

  // Default to Home for other roles or if role not set
  return (
    <Tab.Navigator
      screenOptions={{
        tabBarActiveTintColor: COLORS.primary,
        tabBarInactiveTintColor: COLORS.textSecondary,
        tabBarStyle: { backgroundColor: COLORS.white },
        headerStyle: { backgroundColor: COLORS.primary },
        headerTintColor: COLORS.white,
        headerTitleStyle: { fontWeight: 'bold' },
      }}
    >
      <Tab.Screen
        name="Home"
        component={HomeScreen}
        options={{
          title: 'Inicio',
          tabBarLabel: 'Inicio',
        }}
      />
    </Tab.Navigator>
  );
};

const AppNavigator = () => {
  const { isAuthenticated, isLoading } = useAuth();

  if (isLoading) {
    return null; // Simple loading state
  }

  return (
    <NavigationContainer>
      {isAuthenticated ? <MainNavigator /> : <AuthNavigator />}
    </NavigationContainer>
  );
};

export default AppNavigator;