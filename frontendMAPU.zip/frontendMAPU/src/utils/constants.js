// MAPU Color Palette
export const COLORS = {
  primary: '#0070C9',      // Azul Salud
  secondary: '#2ECC71',    // Verde Naturaleza
  dark: '#2E2E2E',         // Neutro Oscuro
  light: '#F5F7FA',        // Neutro Claro
  textPrimary: '#212121',  // Texto Primario
  textSecondary: '#6C757D', // Texto Secundario
  white: '#FFFFFF',
};

// API Configuration
export const API_BASE_URL = 'http://192.168.1.8:8000/api'; // Adjust if needed

// Alternative configurations (uncomment the one you need):
// export const API_BASE_URL = 'http://192.168.1.100:8000/api'; // Your computer's IP
// export const API_BASE_URL = 'http://localhost:8000/api'; // Web development only
// export const API_BASE_URL = 'http://127.0.0.1:8000/api'; // Alternative localhost


// User Roles
export const ROLES = {
  PACIENTE: 'paciente',
  DOCTOR: 'doctor',
  ADMIN: 'admin',
  SUPERADMIN: 'superadmin',
};

// Function to deeply clean objects and remove nested objects that might cause rendering issues
export const cleanApiData = (data) => {
  if (!data || typeof data !== 'object') return data;

  if (Array.isArray(data)) {
    return data.map(item => cleanApiData(item));
  }

  const cleaned = {};

  for (const [key, value] of Object.entries(data)) {
    // Skip properties that are objects (except arrays which are handled above)
    if (typeof value === 'object' && value !== null && !Array.isArray(value)) {
      // For simple nested objects, try to extract primitive values
      if (key === 'user' && value.name) {
        cleaned[`${key}_name`] = value.name;
      } else if (key === 'doctor' && value.name) {
        cleaned[`${key}_name`] = value.name;
      } else if (key === 'patient' && value.name) {
        cleaned[`${key}_name`] = value.name;
      }
      // Skip other nested objects to prevent rendering issues
      continue;
    }

    // Keep arrays, primitives, and null values
    cleaned[key] = cleanApiData(value);
  }

  return cleaned;
};

// Test Users (Development only)
export const TEST_USERS = {
  SUPERADMIN: {
    email: 'superadmin@sistema.com',
    password: 'superadmin123',
    role: 'superadmin'
  },
  ADMIN: {
    email: 'admin@sistema.com',
    password: 'admin123',
    role: 'admin'
  },
  DOCTOR: {
    email: 'maria.gonzalez@hospital.com',
    password: 'password123',
    role: 'doctor'
  },
  PACIENTE_1: {
    email: 'juan.perez@email.com',
    password: 'password123',
    role: 'paciente'
  },
  PACIENTE_2: {
    email: 'laura.martinez@email.com',
    password: 'password123',
    role: 'paciente'
  }
};