import axios from 'axios';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { API_BASE_URL } from '../utils/constants';

// Create axios instance
const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Request interceptor to add token
api.interceptors.request.use(
  async (config) => {
    try {
      const token = await AsyncStorage.getItem('token');
      if (token) {
        config.headers.Authorization = `Bearer ${token}`;
      }
    } catch (error) {
      console.error('Error getting token from storage:', error);
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Response interceptor for error handling
api.interceptors.response.use(
  (response) => response,
  (error) => {
    console.log('API Error:', error);
    console.log('Error Response:', error.response);
    console.log('Error Message:', error.message);

    if (error.response?.status === 401) {
      // Token expired or invalid
      console.log('Token expired or invalid');
      // Could trigger logout here
    } else if (error.code === 'NETWORK_ERROR' || error.message.includes('Network Error')) {
      console.log('Network connection error - check API URL and server status');
    }
    return Promise.reject(error);
  }
);

// Auth API
export const authAPI = {
  login: (credentials) => api.post('/auth/login', credentials),
  register: (userData) => api.post('/auth/register', userData),
  logout: () => api.post('/auth/logout'),
};

// Patient API
export const patientAPI = {
  getProfile: () => api.get('/pacientes/profile'),
  updateProfile: (data) => api.put('/pacientes/profile', data),
  getAppointments: () => api.get('/pacientes/citas'),
  getMedicalHistory: () => api.get('/pacientes/historial'),
  getBills: () => api.get('/pacientes/facturas'),
};

// Doctor API
export const doctorAPI = {
  getPatients: () => api.get('/medicos/pacientes'),
  getPatientHistory: (patientId) => api.get(`/medicos/pacientes/${patientId}/historial`),
  getAppointments: () => api.get('/medicos/citas'),
  updateAppointmentStatus: (appointmentId, status) => api.put(`/medicos/citas/${appointmentId}/estado`, { estado: status }),
  createMedicalRecord: (data) => api.post('/medicos/historial-clinico', data),
  createTreatment: (data) => api.post('/medicos/tratamientos', data),
  createPrescription: (data) => api.post('/medicos/recetas-medicas', data),
  createExam: (data) => api.post('/medicos/examenes', data),
  getMedications: () => api.get('/medicamentos'),
  searchMedications: (query) => api.get(`/medicamentos/search?q=${query}`),
  getSpecialties: () => api.get('/especialidades'),
};

// Admin API
export const adminAPI = {
  // User management
  getUsers: () => api.get('/admin/users'),
  updateUserRole: (userId, role) => api.put(`/admin/users/${userId}/roles`, { role }),
  deleteUser: (userId) => api.delete(`/admin/users/${userId}`),
  createDoctor: (data) => api.post('/admin/create-doctor', data),
  createAdmin: (data) => api.post('/admin/create-admin', data),

  // CRUD operations for entities
  getPatients: () => api.get('/pacientes'),
  createPatient: (data) => api.post('/pacientes', data),
  updatePatient: (id, data) => api.put(`/pacientes/${id}`, data),
  deletePatient: (id) => api.delete(`/pacientes/${id}`),

  getDoctors: () => api.get('/medicos'),
  createDoctor: (data) => api.post('/medicos', data),
  updateDoctor: (id, data) => api.put(`/medicos/${id}`, data),
  deleteDoctor: (id) => api.delete(`/medicos/${id}`),

  getAppointments: () => api.get('/citas'),
  createAppointment: (data) => api.post('/citas', data),
  updateAppointment: (id, data) => api.put(`/citas/${id}`, data),
  deleteAppointment: (id) => api.delete(`/citas/${id}`),

  // And so on for other entities...
  getDashboardStats: () => api.get('/admin/dashboard/stats'),
  getReports: (type) => api.get(`/admin/reportes/${type}`),
};

// Common API
export const commonAPI = {
  getNotifications: () => api.get('/notificaciones'),
  markNotificationRead: (id) => api.put(`/notificaciones/${id}/read`),
};

export default api;