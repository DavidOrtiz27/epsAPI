import React, { createContext, useState, useEffect, useContext } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { authAPI } from '../services/api';

// Function to deeply clean user object and remove nested objects that might cause rendering issues
const cleanUserObject = (userData) => {
  if (!userData || typeof userData !== 'object') return userData;

  const cleaned = {};

  // Safe properties to keep (primitives and simple arrays)
  const safeProperties = [
    'id', 'name', 'email', 'status', 'created_at', 'updated_at',
    'documento', 'telefono', 'direccion', 'fecha_nacimiento', 'genero'
  ];

  // Copy safe primitive properties
  safeProperties.forEach(prop => {
    if (userData[prop] !== undefined && (typeof userData[prop] !== 'object' || userData[prop] === null)) {
      cleaned[prop] = userData[prop];
    }
  });

  // Handle roles array safely
  if (Array.isArray(userData.roles)) {
    cleaned.roles = userData.roles.map(role => ({
      id: role.id,
      name: role.name,
      // Avoid pivot objects and other nested data
    }));
  }

  return cleaned;
};

const AuthContext = createContext();

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [token, setToken] = useState(null);
  const [isLoading, setIsLoading] = useState(true);

  // Check for stored token on app start
  useEffect(() => {
    const loadStoredAuth = async () => {
      try {
        const storedToken = await AsyncStorage.getItem('token');
        const storedUser = await AsyncStorage.getItem('user');
        if (storedToken && storedUser) {
          const parsedUser = JSON.parse(storedUser);
          // Ensure stored user data is clean
          const cleanUserData = cleanUserObject(parsedUser);
          setToken(storedToken);
          setUser(cleanUserData);
        }
      } catch (error) {
        console.error('Error loading stored auth:', error);
      } finally {
        setIsLoading(false);
      }
    };
    loadStoredAuth();
  }, []);

  const login = async (email, password) => {
    try {
      setIsLoading(true);
      const response = await authAPI.login({ email, password });
      const { user: userData, token: newToken } = response.data;

      // Deep clean user data to avoid rendering issues with nested objects
      const cleanUserData = cleanUserObject(userData);

      setUser(cleanUserData);
      setToken(newToken);
      await AsyncStorage.setItem('token', newToken);
      await AsyncStorage.setItem('user', JSON.stringify(cleanUserData));
      return { success: true };
    } catch (error) {
      return { success: false, error: error.response?.data?.message || 'Login failed' };
    } finally {
      setIsLoading(false);
    }
  };

  const register = async (userData) => {
    try {
      setIsLoading(true);
      const response = await authAPI.register(userData);
      const { user: newUser, token: newToken } = response.data;

      // Clean user data to avoid rendering issues with nested objects
      const cleanUserData = cleanUserObject(newUser);

      setUser(cleanUserData);
      setToken(newToken);
      await AsyncStorage.setItem('token', newToken);
      await AsyncStorage.setItem('user', JSON.stringify(cleanUserData));
      return { success: true };
    } catch (error) {
      return { success: false, error: error.response?.data?.message || 'Registration failed' };
    } finally {
      setIsLoading(false);
    }
  };

  const logout = async () => {
    try {
      if (token) {
        // Set token for this request
        const response = await authAPI.logout();
      }
    } catch (error) {
      console.error('Logout API error:', error);
    } finally {
      setUser(null);
      setToken(null);
      await AsyncStorage.removeItem('token');
      await AsyncStorage.removeItem('user');
    }
  };

  const value = {
    user,
    token,
    isLoading,
    login,
    register,
    logout,
    isAuthenticated: !!token,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};