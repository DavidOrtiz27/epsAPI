import React, { useState, useEffect } from 'react';
import { View, StyleSheet, FlatList, Alert } from 'react-native';
import { Text, Surface, Card, Button, Chip, ActivityIndicator } from 'react-native-paper';
import { COLORS, cleanApiData } from '../../utils/constants';
import { patientAPI } from '../../services/api';

const PatientAppointmentsScreen = () => {
  const [appointments, setAppointments] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadAppointments();
  }, []);

  const loadAppointments = async () => {
    try {
      setLoading(true);
      const response = await patientAPI.getAppointments();
      const appointmentsData = cleanApiData(response.data || []);
      setAppointments(appointmentsData);
    } catch (error) {
      console.error('Error loading appointments:', error);
      Alert.alert('Error', 'No se pudieron cargar las citas. Intente nuevamente.');
      // Fallback to empty array
      setAppointments([]);
    } finally {
      setLoading(false);
    }
  };

  const getStatusColor = (estado) => {
    switch (estado) {
      case 'pendiente': return COLORS.secondary;
      case 'confirmada': return COLORS.primary;
      case 'completada': return '#4CAF50';
      case 'cancelada': return '#F44336';
      default: return COLORS.textSecondary;
    }
  };

  const renderAppointment = ({ item }) => (
    <Card style={styles.card}>
      <Card.Content>
        <View style={styles.appointmentHeader}>
          <Text style={styles.date}>{item.fecha} a las {item.hora}</Text>
          <Chip
            mode="outlined"
            style={[styles.statusChip, { borderColor: getStatusColor(item.estado) }]}
            textStyle={{ color: getStatusColor(item.estado) }}
          >
            {item.estado}
          </Chip>
        </View>

        <Text style={styles.doctor}>Dr. {item.medico}</Text>
        <Text style={styles.specialty}>{item.especialidad}</Text>
        <Text style={styles.reason}>Motivo: {item.motivo}</Text>

        {item.estado === 'pendiente' && (
          <View style={styles.buttonContainer}>
            <Button
              mode="outlined"
              onPress={() => {/* TODO: Reagendar */}}
              style={styles.button}
            >
              Reagendar
            </Button>
            <Button
              mode="contained"
              onPress={() => {/* TODO: Cancelar */}}
              style={styles.button}
              buttonColor="#F44336"
            >
              Cancelar
            </Button>
          </View>
        )}
      </Card.Content>
    </Card>
  );

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator animating={true} size="large" color={COLORS.primary} />
        <Text style={styles.loadingText}>Cargando citas...</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <Surface style={styles.surface} elevation={4}>
        <View style={styles.header}>
          <Text style={styles.title}>Mis Citas</Text>
          <Text style={styles.subtitle}>
            {appointments.filter(a => a.estado === 'pendiente').length} citas pendientes
          </Text>
        </View>

        {appointments.length === 0 ? (
          <View style={styles.emptyContainer}>
            <Text style={styles.emptyEmoji}>📅</Text>
            <Text style={styles.emptyText}>No tienes citas programadas</Text>
            <Text style={styles.emptySubtext}>
              Agenda tu primera cita médica con nosotros
            </Text>
          </View>
        ) : (
          <FlatList
            data={appointments}
            renderItem={renderAppointment}
            keyExtractor={(item) => item.id.toString()}
            showsVerticalScrollIndicator={false}
            contentContainerStyle={styles.listContainer}
          />
        )}

        <View style={styles.footer}>
          <Button
            mode="contained"
            onPress={() => {/* TODO: Navigate to book appointment */}}
            style={styles.bookButton}
            buttonColor={COLORS.primary}
            icon="plus"
          >
            Agendar Nueva Cita
          </Button>
        </View>
      </Surface>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.light,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: COLORS.light,
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
    color: COLORS.textSecondary,
  },
  surface: {
    flex: 1,
    margin: 16,
    borderRadius: 12,
    backgroundColor: COLORS.white,
  },
  header: {
    padding: 16,
    paddingBottom: 8,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: COLORS.textPrimary,
    marginBottom: 4,
  },
  subtitle: {
    fontSize: 14,
    color: COLORS.textSecondary,
  },
  listContainer: {
    padding: 16,
    paddingTop: 0,
  },
  footer: {
    padding: 16,
    paddingTop: 8,
  },
  card: {
    marginBottom: 12,
  },
  appointmentHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  date: {
    fontSize: 16,
    fontWeight: 'bold',
    color: COLORS.primary,
  },
  statusChip: {
    backgroundColor: 'transparent',
  },
  doctor: {
    fontSize: 18,
    fontWeight: 'bold',
    color: COLORS.textPrimary,
    marginBottom: 4,
  },
  specialty: {
    fontSize: 14,
    color: COLORS.textSecondary,
    marginBottom: 8,
  },
  reason: {
    fontSize: 14,
    color: COLORS.textPrimary,
    marginBottom: 12,
  },
  buttonContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  button: {
    flex: 1,
    marginHorizontal: 4,
  },
  bookButton: {
    marginTop: 16,
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 32,
  },
  emptyEmoji: {
    fontSize: 48,
    marginBottom: 16,
  },
  emptyText: {
    textAlign: 'center',
    fontSize: 18,
    color: COLORS.textPrimary,
    marginBottom: 8,
    fontWeight: '500',
  },
  emptySubtext: {
    textAlign: 'center',
    fontSize: 14,
    color: COLORS.textSecondary,
    lineHeight: 20,
  },
  bookButton: {
    marginTop: 16,
  },
});

export default PatientAppointmentsScreen;