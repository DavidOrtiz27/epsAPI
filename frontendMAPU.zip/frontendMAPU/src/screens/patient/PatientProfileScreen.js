import React, { useState, useEffect } from 'react';
import { View, StyleSheet, ScrollView, Alert } from 'react-native';
import { Text, Surface, TextInput, Button, Card, ActivityIndicator } from 'react-native-paper';
import { useAuth } from '../../contexts/AuthContext';
import { COLORS, cleanApiData } from '../../utils/constants';
import { patientAPI } from '../../services/api';

const PatientProfileScreen = () => {
  const { user } = useAuth();
  const [isEditing, setIsEditing] = useState(false);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [profileData, setProfileData] = useState({
    name: user?.name || '',
    email: user?.email || '',
    documento: user?.documento || '',
    telefono: user?.telefono || '',
    direccion: user?.direccion || '',
    fecha_nacimiento: user?.fecha_nacimiento || '',
    genero: user?.genero || '',
  });

  useEffect(() => {
    loadProfile();
  }, []);

  const loadProfile = async () => {
    try {
      setLoading(true);
      const response = await patientAPI.getProfile();
      const profile = cleanApiData(response.data);
      setProfileData({
        name: profile.name || '',
        email: profile.email || '',
        documento: profile.documento || '',
        telefono: profile.telefono || '',
        direccion: profile.direccion || '',
        fecha_nacimiento: profile.fecha_nacimiento || '',
        genero: profile.genero || '',
      });
    } catch (error) {
      console.error('Error loading profile:', error);
      Alert.alert('Error', 'No se pudo cargar el perfil. Verifique su conexión a internet.');
      // Fallback to user data from auth context
      setProfileData({
        name: user?.name || '',
        email: user?.email || '',
        documento: user?.documento || '',
        telefono: user?.telefono || '',
        direccion: user?.direccion || '',
        fecha_nacimiento: user?.fecha_nacimiento || '',
        genero: user?.genero || '',
      });
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async () => {
    try {
      setSaving(true);
      await patientAPI.updateProfile(profileData);
      Alert.alert('Éxito', 'Perfil actualizado correctamente');
      setIsEditing(false);
    } catch (error) {
      console.error('Error updating profile:', error);
      Alert.alert('Error', 'No se pudo actualizar el perfil. Intente nuevamente.');
    } finally {
      setSaving(false);
    }
  };

  const updateProfileData = (field, value) => {
    setProfileData(prev => ({ ...prev, [field]: value }));
  };

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator animating={true} size="large" color={COLORS.primary} />
        <Text style={styles.loadingText}>Cargando perfil...</Text>
      </View>
    );
  }

  return (
    <ScrollView style={styles.container}>
      <Surface style={styles.surface} elevation={4}>
        <Text style={styles.title}>Mi Perfil</Text>

        <Card style={styles.card}>
          <Card.Content>
            {isEditing ? (
              <>
                <TextInput
                  label="Nombre Completo"
                  value={profileData.name}
                  onChangeText={(value) => updateProfileData('name', value)}
                  mode="outlined"
                  style={styles.input}
                />
                <TextInput
                  label="Correo Electrónico"
                  value={profileData.email}
                  onChangeText={(value) => updateProfileData('email', value)}
                  mode="outlined"
                  keyboardType="email-address"
                  style={styles.input}
                />
                <TextInput
                  label="Número de Documento"
                  value={profileData.documento}
                  onChangeText={(value) => updateProfileData('documento', value)}
                  mode="outlined"
                  style={styles.input}
                />
                <TextInput
                  label="Número de Teléfono"
                  value={profileData.telefono}
                  onChangeText={(value) => updateProfileData('telefono', value)}
                  mode="outlined"
                  keyboardType="phone-pad"
                  style={styles.input}
                />
                <TextInput
                  label="Dirección"
                  value={profileData.direccion}
                  onChangeText={(value) => updateProfileData('direccion', value)}
                  mode="outlined"
                  multiline
                  numberOfLines={2}
                  style={styles.input}
                />
                <TextInput
                  label="Fecha de Nacimiento"
                  value={profileData.fecha_nacimiento}
                  onChangeText={(value) => updateProfileData('fecha_nacimiento', value)}
                  mode="outlined"
                  style={styles.input}
                />
                <TextInput
                  label="Género"
                  value={profileData.genero}
                  onChangeText={(value) => updateProfileData('genero', value)}
                  mode="outlined"
                  style={styles.input}
                />

                <View style={styles.buttonContainer}>
                  <Button
                    mode="contained"
                    onPress={handleSave}
                    loading={saving}
                    disabled={saving}
                    style={styles.saveButton}
                    buttonColor={COLORS.primary}
                  >
                    {saving ? 'Guardando...' : 'Guardar Cambios'}
                  </Button>
                  <Button
                    mode="outlined"
                    onPress={() => setIsEditing(false)}
                    disabled={saving}
                    style={styles.cancelButton}
                  >
                    Cancelar
                  </Button>
                </View>
              </>
            ) : (
              <>
                <Text style={styles.label}>Nombre: <Text style={styles.value}>{profileData.name}</Text></Text>
                <Text style={styles.label}>Correo: <Text style={styles.value}>{profileData.email}</Text></Text>
                <Text style={styles.label}>Documento: <Text style={styles.value}>{profileData.documento}</Text></Text>
                <Text style={styles.label}>Teléfono: <Text style={styles.value}>{profileData.telefono || 'No proporcionado'}</Text></Text>
                <Text style={styles.label}>Dirección: <Text style={styles.value}>{profileData.direccion || 'No proporcionada'}</Text></Text>
                <Text style={styles.label}>Fecha de Nacimiento: <Text style={styles.value}>{profileData.fecha_nacimiento || 'No proporcionada'}</Text></Text>
                <Text style={styles.label}>Género: <Text style={styles.value}>{profileData.genero || 'No proporcionado'}</Text></Text>

                <Button
                  mode="contained"
                  onPress={() => setIsEditing(true)}
                  style={styles.editButton}
                  buttonColor={COLORS.secondary}
                >
                  Editar Perfil
                </Button>
              </>
            )}
          </Card.Content>
        </Card>
      </Surface>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.light,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: COLORS.light,
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
    color: COLORS.textSecondary,
  },
  surface: {
    margin: 16,
    padding: 16,
    borderRadius: 12,
    backgroundColor: COLORS.white,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: COLORS.textPrimary,
    marginBottom: 16,
    textAlign: 'center',
  },
  card: {
    marginBottom: 16,
  },
  input: {
    marginBottom: 12,
  },
  label: {
    fontSize: 16,
    color: COLORS.textPrimary,
    marginBottom: 8,
    fontWeight: 'bold',
  },
  value: {
    fontWeight: 'normal',
    color: COLORS.textSecondary,
  },
  buttonContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 16,
  },
  saveButton: {
    flex: 1,
    marginRight: 8,
  },
  cancelButton: {
    flex: 1,
    marginLeft: 8,
  },
  editButton: {
    marginTop: 16,
  },
});

export default PatientProfileScreen;