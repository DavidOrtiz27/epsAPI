import React, { useState, useEffect } from 'react';
import { View, StyleSheet, FlatList, Alert } from 'react-native';
import { Text, Surface, Card, Chip, ActivityIndicator } from 'react-native-paper';
import { COLORS, cleanApiData } from '../../utils/constants';
import { patientAPI } from '../../services/api';

const PatientMedicalHistoryScreen = () => {
  const [medicalHistory, setMedicalHistory] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadMedicalHistory();
  }, []);

  const loadMedicalHistory = async () => {
    try {
      setLoading(true);
      const response = await patientAPI.getMedicalHistory();
      const historyData = cleanApiData(response.data || []);
      setMedicalHistory(historyData);
    } catch (error) {
      console.error('Error loading medical history:', error);
      Alert.alert('Error', 'No se pudo cargar el historial médico. Verifique su conexión a internet.');
      setMedicalHistory([]);
    } finally {
      setLoading(false);
    }
  };

  const renderHistoryItem = ({ item }) => (
    <Card style={styles.card}>
      <Card.Content>
        <View style={styles.header}>
          <Text style={styles.date}>{item.fecha}</Text>
          <Chip mode="outlined" style={styles.chip}>
            Consulta
          </Chip>
        </View>

        <Text style={styles.doctor}>Dr. {item.medico}</Text>
        <Text style={styles.diagnosis}>Diagnóstico: {item.diagnostico}</Text>
        <Text style={styles.treatment}>Tratamiento: {item.tratamiento}</Text>
        <Text style={styles.notes}>Notas: {item.notas}</Text>
      </Card.Content>
    </Card>
  );

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator animating={true} size="large" color={COLORS.primary} />
        <Text style={styles.loadingText}>Cargando historial médico...</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <Surface style={styles.surface} elevation={4}>
        <Text style={styles.title}>Historial Médico</Text>

        {medicalHistory.length === 0 ? (
          <Text style={styles.emptyText}>No se encontraron registros médicos</Text>
        ) : (
          <FlatList
            data={medicalHistory}
            renderItem={renderHistoryItem}
            keyExtractor={(item) => item.id.toString()}
            showsVerticalScrollIndicator={false}
          />
        )}
      </Surface>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.light,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: COLORS.light,
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
    color: COLORS.textSecondary,
  },
  surface: {
    flex: 1,
    margin: 16,
    padding: 16,
    borderRadius: 12,
    backgroundColor: COLORS.white,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: COLORS.textPrimary,
    marginBottom: 16,
    textAlign: 'center',
  },
  card: {
    marginBottom: 12,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  date: {
    fontSize: 16,
    fontWeight: 'bold',
    color: COLORS.primary,
  },
  chip: {
    borderColor: COLORS.secondary,
  },
  doctor: {
    fontSize: 18,
    fontWeight: 'bold',
    color: COLORS.textPrimary,
    marginBottom: 8,
  },
  diagnosis: {
    fontSize: 16,
    color: COLORS.textPrimary,
    marginBottom: 4,
  },
  treatment: {
    fontSize: 14,
    color: COLORS.textSecondary,
    marginBottom: 4,
  },
  notes: {
    fontSize: 14,
    color: COLORS.textPrimary,
    fontStyle: 'italic',
  },
  emptyText: {
    textAlign: 'center',
    fontSize: 16,
    color: COLORS.textSecondary,
    marginTop: 32,
  },
});

export default PatientMedicalHistoryScreen;