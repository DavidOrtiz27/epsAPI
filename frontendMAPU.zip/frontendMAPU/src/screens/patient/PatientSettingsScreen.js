import React from 'react';
import { View, StyleSheet, ScrollView, Alert } from 'react-native';
import { Text, Surface, Card, Button, List, Switch } from 'react-native-paper';
import { useAuth } from '../../contexts/AuthContext';
import { useToast } from '../../contexts/ToastContext';
import { COLORS } from '../../utils/constants';

const PatientSettingsScreen = ({ navigation }) => {
  const { user, logout } = useAuth();
  const { showSuccess, showError } = useToast();

  const handleLogout = () => {
    Alert.alert(
      'Cerrar Sesión',
      '¿Estás seguro de que quieres cerrar sesión?',
      [
        {
          text: 'Cancelar',
          style: 'cancel',
        },
        {
          text: 'Cerrar Sesión',
          style: 'destructive',
          onPress: async () => {
            try {
              await logout();
              showSuccess('Sesión cerrada exitosamente');
            } catch (error) {
              showError('Error al cerrar sesión');
            }
          },
        },
      ]
    );
  };

  const settingsOptions = [
    {
      title: 'Notificaciones',
      description: 'Recibir notificaciones de citas y recordatorios',
      icon: 'bell',
      action: 'toggle',
      value: true, // This would come from user preferences
    },
    {
      title: 'Recordatorios',
      description: 'Recordatorios automáticos de medicamentos',
      icon: 'clock',
      action: 'toggle',
      value: false,
    },
    {
      title: 'Privacidad',
      description: 'Configuración de privacidad de datos',
      icon: 'shield',
      action: 'navigate',
      screen: 'PrivacySettings',
    },
    {
      title: 'Ayuda',
      description: 'Centro de ayuda y soporte',
      icon: 'help-circle',
      action: 'navigate',
      screen: 'Help',
    },
    {
      title: 'Acerca de',
      description: 'Información sobre MAPU',
      icon: 'information',
      action: 'navigate',
      screen: 'About',
    },
  ];

  const handleSettingPress = (setting) => {
    if (setting.action === 'navigate') {
      // navigation.navigate(setting.screen);
      showInfo('Función próximamente disponible');
    }
  };

  return (
    <ScrollView style={styles.container}>
      <Surface style={styles.surface} elevation={4}>
        <Text style={styles.title}>Configuración</Text>

        {/* User Info Card */}
        <Card style={styles.userCard}>
          <Card.Content>
            <View style={styles.userInfo}>
              <View style={styles.userAvatar}>
                <Text style={styles.userInitial}>
                  {user?.name?.charAt(0)?.toUpperCase() || 'U'}
                </Text>
              </View>
              <View style={styles.userDetails}>
                <Text style={styles.userName}>{user?.name || 'Usuario'}</Text>
                <Text style={styles.userEmail}>{user?.email || ''}</Text>
                <Text style={styles.userRole}>
                  {user?.roles?.[0]?.name === 'paciente' ? 'Paciente' : 'Usuario'}
                </Text>
              </View>
            </View>
          </Card.Content>
        </Card>

        {/* Settings Options */}
        <Card style={styles.settingsCard}>
          <Card.Content>
            <Text style={styles.sectionTitle}>Preferencias</Text>
            {settingsOptions.map((setting, index) => (
              <List.Item
                key={index}
                title={setting.title}
                description={setting.description}
                left={props => <List.Icon {...props} icon={setting.icon} />}
                right={props => {
                  if (setting.action === 'toggle') {
                    return <Switch value={setting.value} onValueChange={() => {}} />;
                  }
                  return <List.Icon {...props} icon="chevron-right" />;
                }}
                onPress={() => handleSettingPress(setting)}
                style={styles.listItem}
              />
            ))}
          </Card.Content>
        </Card>

        {/* Account Actions */}
        <Card style={styles.accountCard}>
          <Card.Content>
            <Text style={styles.sectionTitle}>Cuenta</Text>

            <Button
              mode="outlined"
              onPress={() => navigation.navigate('Profile')}
              style={styles.accountButton}
              icon="account-edit"
            >
              Editar Perfil
            </Button>

            <Button
              mode="outlined"
              onPress={() => {/* TODO: Change password */}}
              style={styles.accountButton}
              icon="lock-reset"
            >
              Cambiar Contraseña
            </Button>

            <Button
              mode="outlined"
              onPress={() => {/* TODO: Export data */}}
              style={styles.accountButton}
              icon="download"
            >
              Exportar Datos
            </Button>
          </Card.Content>
        </Card>

        {/* Logout Button */}
        <Button
          mode="contained"
          onPress={handleLogout}
          style={styles.logoutButton}
          buttonColor="#F44336"
          icon="logout"
        >
          Cerrar Sesión
        </Button>

        {/* App Version */}
        <Text style={styles.versionText}>MAPU v1.0.0</Text>
      </Surface>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.light,
  },
  surface: {
    margin: 16,
    padding: 16,
    borderRadius: 12,
    backgroundColor: COLORS.white,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: COLORS.textPrimary,
    marginBottom: 20,
    textAlign: 'center',
  },
  userCard: {
    marginBottom: 16,
  },
  userInfo: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  userAvatar: {
    width: 60,
    height: 60,
    borderRadius: 30,
    backgroundColor: COLORS.primary,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 16,
  },
  userInitial: {
    fontSize: 24,
    fontWeight: 'bold',
    color: COLORS.white,
  },
  userDetails: {
    flex: 1,
  },
  userName: {
    fontSize: 18,
    fontWeight: 'bold',
    color: COLORS.textPrimary,
  },
  userEmail: {
    fontSize: 14,
    color: COLORS.textSecondary,
  },
  userRole: {
    fontSize: 12,
    color: COLORS.primary,
    fontWeight: '500',
  },
  settingsCard: {
    marginBottom: 16,
  },
  accountCard: {
    marginBottom: 20,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: COLORS.textPrimary,
    marginBottom: 12,
  },
  listItem: {
    paddingVertical: 8,
  },
  accountButton: {
    marginBottom: 8,
    justifyContent: 'flex-start',
  },
  logoutButton: {
    marginTop: 8,
    marginBottom: 16,
  },
  versionText: {
    textAlign: 'center',
    fontSize: 12,
    color: COLORS.textSecondary,
  },
});

export default PatientSettingsScreen;