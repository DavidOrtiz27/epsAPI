import React, { useState, useEffect } from 'react';
import { View, StyleSheet, FlatList, Alert } from 'react-native';
import { Text, Surface, Card, Button, Chip, ActivityIndicator } from 'react-native-paper';
import { COLORS, cleanApiData } from '../../utils/constants';
import { patientAPI } from '../../services/api';

const PatientBillsScreen = () => {
  const [bills, setBills] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadBills();
  }, []);

  const loadBills = async () => {
    try {
      setLoading(true);
      const response = await patientAPI.getBills();
      const billsData = cleanApiData(response.data || []);
      setBills(billsData);
    } catch (error) {
      console.error('Error loading bills:', error);
      Alert.alert('Error', 'No se pudieron cargar las facturas. Verifique su conexión a internet.');
      setBills([]);
    } finally {
      setLoading(false);
    }
  };

  const getStatusColor = (estado) => {
    switch (estado) {
      case 'pagada': return '#4CAF50';
      case 'pendiente': return COLORS.secondary;
      case 'vencida': return '#F44336';
      default: return COLORS.textSecondary;
    }
  };

  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('es-CO', {
      style: 'currency',
      currency: 'COP',
    }).format(amount);
  };

  const renderBill = ({ item }) => (
    <Card style={styles.card}>
      <Card.Content>
        <View style={styles.header}>
          <Text style={styles.date}>{item.fecha}</Text>
          <Chip
            mode="outlined"
            style={[styles.statusChip, { borderColor: getStatusColor(item.estado) }]}
            textStyle={{ color: getStatusColor(item.estado) }}
          >
            {item.estado}
          </Chip>
        </View>

        <Text style={styles.service}>{item.servicio}</Text>
        <Text style={styles.amount}>{formatCurrency(item.monto)}</Text>

        {item.fecha_pago && (
          <Text style={styles.paymentDate}>Paid on: {item.fecha_pago}</Text>
        )}

        {item.estado === 'pendiente' && (
          <Button
            mode="contained"
            onPress={() => {/* TODO: Pay bill */}}
            style={styles.payButton}
            buttonColor={COLORS.primary}
          >
            Pay Now
          </Button>
        )}
      </Card.Content>
    </Card>
  );

  const totalPending = bills
    .filter(bill => bill.estado === 'pendiente')
    .reduce((sum, bill) => sum + bill.monto, 0);

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator animating={true} size="large" color={COLORS.primary} />
        <Text style={styles.loadingText}>Cargando facturas...</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <Surface style={styles.surface} elevation={4}>
        <Text style={styles.title}>Mis Facturas</Text>

        {totalPending > 0 && (
          <Card style={styles.summaryCard}>
            <Card.Content>
              <Text style={styles.summaryText}>
                Total Pendiente: {formatCurrency(totalPending)}
              </Text>
            </Card.Content>
          </Card>
        )}

        {bills.length === 0 ? (
          <Text style={styles.emptyText}>No se encontraron facturas</Text>
        ) : (
          <FlatList
            data={bills}
            renderItem={renderBill}
            keyExtractor={(item) => item.id.toString()}
            showsVerticalScrollIndicator={false}
          />
        )}
      </Surface>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.light,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: COLORS.light,
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
    color: COLORS.textSecondary,
  },
  surface: {
    flex: 1,
    margin: 16,
    padding: 16,
    borderRadius: 12,
    backgroundColor: COLORS.white,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: COLORS.textPrimary,
    marginBottom: 16,
    textAlign: 'center',
  },
  summaryCard: {
    marginBottom: 16,
    backgroundColor: COLORS.secondary + '20', // Light secondary background
  },
  summaryText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: COLORS.secondary,
    textAlign: 'center',
  },
  card: {
    marginBottom: 12,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  date: {
    fontSize: 16,
    fontWeight: 'bold',
    color: COLORS.primary,
  },
  statusChip: {
    backgroundColor: 'transparent',
  },
  service: {
    fontSize: 18,
    fontWeight: 'bold',
    color: COLORS.textPrimary,
    marginBottom: 4,
  },
  amount: {
    fontSize: 20,
    fontWeight: 'bold',
    color: COLORS.primary,
    marginBottom: 8,
  },
  paymentDate: {
    fontSize: 14,
    color: COLORS.textSecondary,
    marginBottom: 12,
  },
  payButton: {
    marginTop: 8,
  },
  emptyText: {
    textAlign: 'center',
    fontSize: 16,
    color: COLORS.textSecondary,
    marginTop: 32,
  },
});

export default PatientBillsScreen;