import React, { useState, useEffect } from 'react';
import { View, StyleSheet, FlatList, TouchableOpacity, Alert } from 'react-native';
import { Text, Surface, Card, Button, Searchbar, Chip, FAB, Portal, Modal, TextInput } from 'react-native-paper';
import { COLORS, ROLES } from '../../utils/constants';

const AdminUserManagementScreen = () => {
  const [users, setUsers] = useState([]);
  const [filteredUsers, setFilteredUsers] = useState([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [modalVisible, setModalVisible] = useState(false);
  const [selectedUser, setSelectedUser] = useState(null);
  const [newUser, setNewUser] = useState({
    name: '',
    email: '',
    role: ROLES.PACIENTE,
  });

  useEffect(() => {
    // TODO: Fetch users from API
    // Mock data for now
    setUsers([
      {
        id: 1,
        name: 'Juan Pérez',
        email: 'juan.perez@email.com',
        role: ROLES.PACIENTE,
        status: 'active',
        created_at: '2025-01-15',
      },
      {
        id: 2,
        name: 'Dr. María González',
        email: 'maria.gonzalez@hospital.com',
        role: ROLES.DOCTOR,
        status: 'active',
        created_at: '2024-11-20',
      },
      {
        id: 3,
        name: 'Admin User',
        email: 'admin@sistema.com',
        role: ROLES.ADMIN,
        status: 'active',
        created_at: '2024-10-01',
      },
      {
        id: 4,
        name: 'Carlos Rodríguez',
        email: 'carlos.rodriguez@email.com',
        role: ROLES.PACIENTE,
        status: 'inactive',
        created_at: '2025-02-10',
      },
    ]);
    setFilteredUsers(users);
  }, []);

  useEffect(() => {
    if (searchQuery) {
      const filtered = users.filter(user =>
        user.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        user.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
        user.role.toLowerCase().includes(searchQuery.toLowerCase())
      );
      setFilteredUsers(filtered);
    } else {
      setFilteredUsers(users);
    }
  }, [searchQuery, users]);

  const getRoleColor = (role) => {
    switch (role) {
      case ROLES.ADMIN:
      case ROLES.SUPERADMIN:
        return '#F44336';
      case ROLES.DOCTOR:
        return COLORS.secondary;
      case ROLES.PACIENTE:
        return COLORS.primary;
      default:
        return COLORS.textSecondary;
    }
  };

  const handleRoleChange = (userId, newRole) => {
    Alert.alert(
      'Change Role',
      `Are you sure you want to change this user's role to ${newRole}?`,
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Confirm',
          onPress: () => {
            setUsers(prev =>
              prev.map(user =>
                user.id === userId ? { ...user, role: newRole } : user
              )
            );
            // TODO: API call to update user role
          },
        },
      ]
    );
  };

  const handleStatusChange = (userId, newStatus) => {
    const action = newStatus === 'active' ? 'activate' : 'deactivate';
    Alert.alert(
      'Change Status',
      `Are you sure you want to ${action} this user?`,
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Confirm',
          onPress: () => {
            setUsers(prev =>
              prev.map(user =>
                user.id === userId ? { ...user, status: newStatus } : user
              )
            );
            // TODO: API call to update user status
          },
        },
      ]
    );
  };

  const handleCreateUser = () => {
    if (!newUser.name || !newUser.email) {
      Alert.alert('Error', 'Please fill in name and email');
      return;
    }

    // TODO: API call to create user
    const user = {
      id: Date.now(),
      ...newUser,
      status: 'active',
      created_at: new Date().toISOString().split('T')[0],
    };

    setUsers(prev => [...prev, user]);
    setNewUser({ name: '', email: '', role: ROLES.PACIENTE });
    setModalVisible(false);
  };

  const renderUser = ({ item }) => (
    <Card style={styles.card}>
      <Card.Content>
        <View style={styles.userHeader}>
          <Text style={styles.userName}>{item.name}</Text>
          <Chip
            mode="outlined"
            style={[styles.roleChip, { borderColor: getRoleColor(item.role) }]}
            textStyle={{ color: getRoleColor(item.role) }}
          >
            {item.role}
          </Chip>
        </View>

        <Text style={styles.userEmail}>{item.email}</Text>
        <Text style={styles.userInfo}>Status: {item.status}</Text>
        <Text style={styles.userInfo}>Created: {item.created_at}</Text>

        <View style={styles.actionButtons}>
          <TouchableOpacity
            style={[styles.actionButton, { backgroundColor: COLORS.secondary }]}
            onPress={() => {
              const newRole = item.role === ROLES.PACIENTE ? ROLES.DOCTOR :
                             item.role === ROLES.DOCTOR ? ROLES.ADMIN : ROLES.PACIENTE;
              handleRoleChange(item.id, newRole);
            }}
          >
            <Text style={styles.actionButtonText}>Change Role</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={[styles.actionButton, {
              backgroundColor: item.status === 'active' ? '#F44336' : '#4CAF50'
            }]}
            onPress={() => handleStatusChange(item.id, item.status === 'active' ? 'inactive' : 'active')}
          >
            <Text style={styles.actionButtonText}>
              {item.status === 'active' ? 'Deactivate' : 'Activate'}
            </Text>
          </TouchableOpacity>
        </View>
      </Card.Content>
    </Card>
  );

  return (
    <View style={styles.container}>
      <Surface style={styles.surface} elevation={4}>
        <Text style={styles.title}>Gestión de Usuarios</Text>

        <Searchbar
          placeholder="Buscar por nombre, correo o rol"
          onChangeText={setSearchQuery}
          value={searchQuery}
          style={styles.searchbar}
        />

        {filteredUsers.length === 0 ? (
          <Text style={styles.emptyText}>No se encontraron usuarios</Text>
        ) : (
          <FlatList
            data={filteredUsers}
            renderItem={renderUser}
            keyExtractor={(item) => item.id.toString()}
            showsVerticalScrollIndicator={false}
          />
        )}
      </Surface>

      <FAB
        icon="plus"
        style={styles.fab}
        onPress={() => setModalVisible(true)}
      />

      <Portal>
        <Modal
          visible={modalVisible}
          onDismiss={() => setModalVisible(false)}
          contentContainerStyle={styles.modalContainer}
        >
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>Create New User</Text>

            <TextInput
              label="Full Name"
              value={newUser.name}
              onChangeText={(value) => setNewUser(prev => ({ ...prev, name: value }))}
              mode="outlined"
              style={styles.input}
            />

            <TextInput
              label="Email"
              value={newUser.email}
              onChangeText={(value) => setNewUser(prev => ({ ...prev, email: value }))}
              mode="outlined"
              keyboardType="email-address"
              autoCapitalize="none"
              style={styles.input}
            />

            <Text style={styles.label}>Role</Text>
            <View style={styles.roleButtons}>
              <TouchableOpacity
                style={[styles.roleButton, newUser.role === ROLES.PACIENTE && styles.roleButtonActive]}
                onPress={() => setNewUser(prev => ({ ...prev, role: ROLES.PACIENTE }))}
              >
                <Text style={[styles.roleButtonText, newUser.role === ROLES.PACIENTE && styles.roleButtonTextActive]}>
                  Patient
                </Text>
              </TouchableOpacity>

              <TouchableOpacity
                style={[styles.roleButton, newUser.role === ROLES.DOCTOR && styles.roleButtonActive]}
                onPress={() => setNewUser(prev => ({ ...prev, role: ROLES.DOCTOR }))}
              >
                <Text style={[styles.roleButtonText, newUser.role === ROLES.DOCTOR && styles.roleButtonTextActive]}>
                  Doctor
                </Text>
              </TouchableOpacity>

              <TouchableOpacity
                style={[styles.roleButton, newUser.role === ROLES.ADMIN && styles.roleButtonActive]}
                onPress={() => setNewUser(prev => ({ ...prev, role: ROLES.ADMIN }))}
              >
                <Text style={[styles.roleButtonText, newUser.role === ROLES.ADMIN && styles.roleButtonTextActive]}>
                  Admin
                </Text>
              </TouchableOpacity>
            </View>

            <View style={styles.modalButtons}>
              <Button
                mode="outlined"
                onPress={() => setModalVisible(false)}
                style={styles.cancelButton}
              >
                Cancel
              </Button>
              <Button
                mode="contained"
                onPress={handleCreateUser}
                style={styles.createButton}
                buttonColor={COLORS.primary}
              >
                Create User
              </Button>
            </View>
          </View>
        </Modal>
      </Portal>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.light,
  },
  surface: {
    flex: 1,
    margin: 16,
    padding: 16,
    borderRadius: 12,
    backgroundColor: COLORS.white,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: COLORS.textPrimary,
    marginBottom: 16,
    textAlign: 'center',
  },
  searchbar: {
    marginBottom: 16,
  },
  card: {
    marginBottom: 12,
  },
  userHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  userName: {
    fontSize: 18,
    fontWeight: 'bold',
    color: COLORS.textPrimary,
    flex: 1,
  },
  roleChip: {
    backgroundColor: 'transparent',
  },
  userEmail: {
    fontSize: 16,
    color: COLORS.textSecondary,
    marginBottom: 4,
  },
  userInfo: {
    fontSize: 14,
    color: COLORS.textSecondary,
    marginBottom: 2,
  },
  actionButtons: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 12,
  },
  actionButton: {
    flex: 1,
    padding: 10,
    borderRadius: 8,
    marginHorizontal: 4,
    alignItems: 'center',
  },
  actionButtonText: {
    color: COLORS.white,
    fontWeight: 'bold',
    fontSize: 12,
  },
  emptyText: {
    textAlign: 'center',
    fontSize: 16,
    color: COLORS.textSecondary,
    marginTop: 32,
  },
  fab: {
    position: 'absolute',
    margin: 16,
    right: 0,
    bottom: 0,
    backgroundColor: COLORS.primary,
  },
  modalContainer: {
    backgroundColor: COLORS.white,
    margin: 20,
    borderRadius: 12,
  },
  modalContent: {
    padding: 20,
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: COLORS.textPrimary,
    marginBottom: 16,
    textAlign: 'center',
  },
  input: {
    marginBottom: 12,
  },
  label: {
    fontSize: 16,
    color: COLORS.textPrimary,
    marginBottom: 8,
    marginTop: 8,
  },
  roleButtons: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 16,
  },
  roleButton: {
    flex: 1,
    padding: 12,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: COLORS.light,
    marginHorizontal: 4,
    alignItems: 'center',
  },
  roleButtonActive: {
    backgroundColor: COLORS.primary,
    borderColor: COLORS.primary,
  },
  roleButtonText: {
    fontSize: 14,
    color: COLORS.textSecondary,
  },
  roleButtonTextActive: {
    color: COLORS.white,
  },
  modalButtons: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 16,
  },
  cancelButton: {
    flex: 1,
    marginRight: 8,
  },
  createButton: {
    flex: 1,
    marginLeft: 8,
  },
});

export default AdminUserManagementScreen;