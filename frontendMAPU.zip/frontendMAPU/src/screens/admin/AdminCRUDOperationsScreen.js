import React, { useState } from 'react';
import { View, StyleSheet, ScrollView } from 'react-native';
import { Text, Surface, Card, Button, DataTable, FAB, Portal, Modal, TextInput } from 'react-native-paper';
import { COLORS } from '../../utils/constants';

const AdminCRUDOperationsScreen = () => {
  const [activeTab, setActiveTab] = useState('patients');
  const [modalVisible, setModalVisible] = useState(false);
  const [selectedEntity, setSelectedEntity] = useState(null);
  const [newEntity, setNewEntity] = useState({});

  const tabs = [
    { key: 'patients', title: 'Patients' },
    { key: 'doctors', title: 'Doctors' },
    { key: 'appointments', title: 'Appointments' },
    { key: 'medicines', title: 'Medicines' },
  ];

  const mockData = {
    patients: [
      { id: 1, name: 'Juan Pérez', email: 'juan@email.com', phone: '3001234567', status: 'Active' },
      { id: 2, name: 'María García', email: 'maria@email.com', phone: '3019876543', status: 'Active' },
    ],
    doctors: [
      { id: 1, name: 'Dr. Carlos Rodríguez', specialty: 'Cardiology', email: 'carlos@hospital.com', status: 'Active' },
      { id: 2, name: 'Dr. Ana López', specialty: 'Pediatrics', email: 'ana@hospital.com', status: 'Active' },
    ],
    appointments: [
      { id: 1, patient: 'Juan Pérez', doctor: 'Dr. Carlos Rodríguez', date: '2025-09-20', time: '10:00', status: 'Confirmed' },
      { id: 2, patient: 'María García', doctor: 'Dr. Ana López', date: '2025-09-21', time: '14:30', status: 'Pending' },
    ],
    medicines: [
      { id: 1, name: 'Amoxicillin', category: 'Antibiotic', stock: 150, price: 25000 },
      { id: 2, name: 'Ibuprofen', category: 'Pain Relief', stock: 200, price: 15000 },
    ],
  };

  const getEntityFields = (entityType) => {
    switch (entityType) {
      case 'patients':
        return ['name', 'email', 'phone'];
      case 'doctors':
        return ['name', 'specialty', 'email'];
      case 'appointments':
        return ['patient', 'doctor', 'date', 'time'];
      case 'medicines':
        return ['name', 'category', 'stock', 'price'];
      default:
        return [];
    }
  };

  const handleCreate = (entityType) => {
    setSelectedEntity(entityType);
    setNewEntity({});
    setModalVisible(true);
  };

  const handleEdit = (entityType, item) => {
    setSelectedEntity(entityType);
    setNewEntity(item);
    setModalVisible(true);
  };

  const handleDelete = (entityType, id) => {
    // TODO: Implement delete functionality
    console.log(`Delete ${entityType} with id ${id}`);
  };

  const handleSave = () => {
    // TODO: Implement save functionality
    console.log('Save entity:', selectedEntity, newEntity);
    setModalVisible(false);
  };

  const renderTable = (entityType) => {
    const data = mockData[entityType] || [];
    const fields = getEntityFields(entityType);

    return (
      <DataTable>
        <DataTable.Header>
          {fields.map(field => (
            <DataTable.Title key={field} style={styles.tableCell}>
              {field.charAt(0).toUpperCase() + field.slice(1)}
            </DataTable.Title>
          ))}
          <DataTable.Title style={styles.tableCell}>Actions</DataTable.Title>
        </DataTable.Header>

        {data.map((item) => (
          <DataTable.Row key={item.id}>
            {fields.map(field => (
              <DataTable.Cell key={field} style={styles.tableCell}>
                {item[field]}
              </DataTable.Cell>
            ))}
            <DataTable.Cell style={styles.tableCell}>
              <View style={styles.actionButtons}>
                <Button
                  mode="text"
                  onPress={() => handleEdit(entityType, item)}
                  textColor={COLORS.secondary}
                  compact
                >
                  Edit
                </Button>
                <Button
                  mode="text"
                  onPress={() => handleDelete(entityType, item.id)}
                  textColor="#F44336"
                  compact
                >
                  Delete
                </Button>
              </View>
            </DataTable.Cell>
          </DataTable.Row>
        ))}
      </DataTable>
    );
  };

  const renderForm = () => {
    if (!selectedEntity) return null;

    const fields = getEntityFields(selectedEntity);

    return (
      <View>
        <Text style={styles.modalTitle}>
          {newEntity.id ? 'Edit' : 'Create'} {selectedEntity.slice(0, -1)}
        </Text>

        {fields.map(field => (
          <TextInput
            key={field}
            label={field.charAt(0).toUpperCase() + field.slice(1)}
            value={newEntity[field] || ''}
            onChangeText={(value) => setNewEntity(prev => ({ ...prev, [field]: value }))}
            mode="outlined"
            style={styles.input}
          />
        ))}

        <View style={styles.modalButtons}>
          <Button
            mode="outlined"
            onPress={() => setModalVisible(false)}
            style={styles.cancelButton}
          >
            Cancel
          </Button>
          <Button
            mode="contained"
            onPress={handleSave}
            style={styles.saveButton}
            buttonColor={COLORS.primary}
          >
            {newEntity.id ? 'Update' : 'Create'}
          </Button>
        </View>
      </View>
    );
  };

  return (
    <View style={styles.container}>
      <Surface style={styles.surface} elevation={4}>
        <Text style={styles.title}>Operaciones CRUD</Text>

        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.tabContainer}>
          {tabs.map(tab => (
            <Button
              key={tab.key}
              mode={activeTab === tab.key ? 'contained' : 'outlined'}
              onPress={() => setActiveTab(tab.key)}
              style={[styles.tabButton, activeTab === tab.key && styles.activeTabButton]}
              buttonColor={activeTab === tab.key ? COLORS.primary : undefined}
            >
              {tab.title}
            </Button>
          ))}
        </ScrollView>

        <Card style={styles.tableCard}>
          <Card.Content style={styles.tableContainer}>
            {renderTable(activeTab)}
          </Card.Content>
        </Card>
      </Surface>

      <FAB
        icon="plus"
        style={styles.fab}
        onPress={() => handleCreate(activeTab)}
      />

      <Portal>
        <Modal
          visible={modalVisible}
          onDismiss={() => setModalVisible(false)}
          contentContainerStyle={styles.modalContainer}
        >
          <ScrollView style={styles.modalContent}>
            {renderForm()}
          </ScrollView>
        </Modal>
      </Portal>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.light,
  },
  surface: {
    flex: 1,
    margin: 16,
    padding: 16,
    borderRadius: 12,
    backgroundColor: COLORS.white,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: COLORS.textPrimary,
    marginBottom: 16,
    textAlign: 'center',
  },
  tabContainer: {
    marginBottom: 16,
  },
  tabButton: {
    marginRight: 8,
    marginBottom: 8,
  },
  activeTabButton: {
    elevation: 2,
  },
  tableCard: {
    flex: 1,
  },
  tableContainer: {
    padding: 0,
  },
  tableCell: {
    flex: 1,
    paddingHorizontal: 8,
  },
  actionButtons: {
    flexDirection: 'row',
    justifyContent: 'flex-start',
  },
  fab: {
    position: 'absolute',
    margin: 16,
    right: 0,
    bottom: 0,
    backgroundColor: COLORS.primary,
  },
  modalContainer: {
    backgroundColor: COLORS.white,
    margin: 20,
    borderRadius: 12,
    maxHeight: '80%',
  },
  modalContent: {
    padding: 20,
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: COLORS.textPrimary,
    marginBottom: 16,
    textAlign: 'center',
  },
  input: {
    marginBottom: 12,
  },
  modalButtons: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 16,
  },
  cancelButton: {
    flex: 1,
    marginRight: 8,
  },
  saveButton: {
    flex: 1,
    marginLeft: 8,
  },
});

export default AdminCRUDOperationsScreen;