import React, { useState, useEffect } from 'react';
import { View, StyleSheet, ScrollView, Alert } from 'react-native';
import { Text, Surface, Card, Title, Paragraph, ActivityIndicator } from 'react-native-paper';
import { COLORS, cleanApiData } from '../../utils/constants';
import { adminAPI } from '../../services/api';

const AdminDashboardScreen = () => {
  const [stats, setStats] = useState({
    totalPatients: 0,
    totalDoctors: 0,
    totalAppointments: 0,
    pendingAppointments: 0,
    monthlyRevenue: 0,
    activeUsers: 0,
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadDashboardStats();
  }, []);

  const loadDashboardStats = async () => {
    try {
      setLoading(true);
      const response = await adminAPI.getDashboardStats();
      const statsData = cleanApiData(response.data || {});
      setStats({
        totalPatients: statsData.totalPatients || 0,
        totalDoctors: statsData.totalDoctors || 0,
        totalAppointments: statsData.totalAppointments || 0,
        pendingAppointments: statsData.pendingAppointments || 0,
        monthlyRevenue: statsData.monthlyRevenue || 0,
        activeUsers: statsData.activeUsers || 0,
      });
    } catch (error) {
      console.error('Error loading dashboard stats:', error);
      Alert.alert('Error', 'No se pudieron cargar las estadísticas. Verifique su conexión a internet.');
      // Fallback to zero values
      setStats({
        totalPatients: 0,
        totalDoctors: 0,
        totalAppointments: 0,
        pendingAppointments: 0,
        monthlyRevenue: 0,
        activeUsers: 0,
      });
    } finally {
      setLoading(false);
    }
  };

  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('es-CO', {
      style: 'currency',
      currency: 'COP',
    }).format(amount);
  };

  const StatCard = ({ title, value, subtitle, color = COLORS.primary }) => (
    <Card style={[styles.statCard, { borderLeftColor: color }]}>
      <Card.Content>
        <Title style={[styles.statValue, { color }]}>{value}</Title>
        <Paragraph style={styles.statTitle}>{title}</Paragraph>
        {subtitle && <Paragraph style={styles.statSubtitle}>{subtitle}</Paragraph>}
      </Card.Content>
    </Card>
  );

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator animating={true} size="large" color={COLORS.primary} />
        <Text style={styles.loadingText}>Cargando estadísticas...</Text>
      </View>
    );
  }

  return (
    <ScrollView style={styles.container}>
      <Surface style={styles.surface} elevation={4}>
        <Text style={styles.title}>Panel de Control</Text>

        <View style={styles.statsGrid}>
          <StatCard
            title="Total Pacientes"
            value={stats.totalPatients.toLocaleString()}
            subtitle="Usuarios registrados"
            color={COLORS.primary}
          />

          <StatCard
            title="Total Doctores"
            value={stats.totalDoctors.toLocaleString()}
            subtitle="Personal médico activo"
            color={COLORS.secondary}
          />

          <StatCard
            title="Citas"
            value={stats.totalAppointments.toLocaleString()}
            subtitle={`${stats.pendingAppointments} pendientes`}
            color="#FF9800"
          />

          <StatCard
            title="Ingresos Mensuales"
            value={formatCurrency(stats.monthlyRevenue)}
            subtitle="Este mes"
            color="#4CAF50"
          />

          <StatCard
            title="Usuarios Activos"
            value={stats.activeUsers.toLocaleString()}
            subtitle="Últimos 30 días"
            color="#9C27B0"
          />
        </View>

        <Card style={styles.recentActivityCard}>
          <Card.Content>
            <Title style={styles.sectionTitle}>Actividad Reciente</Title>

            <View style={styles.activityItem}>
              <Text style={styles.activityText}>Nuevo paciente registrado: Juan Pérez</Text>
              <Text style={styles.activityTime}>Hace 2 horas</Text>
            </View>

            <View style={styles.activityItem}>
              <Text style={styles.activityText}>Cita completada: María García</Text>
              <Text style={styles.activityTime}>Hace 4 horas</Text>
            </View>

            <View style={styles.activityItem}>
              <Text style={styles.activityText}>Nuevo doctor agregado: Dr. Carlos Rodríguez</Text>
              <Text style={styles.activityTime}>Hace 1 día</Text>
            </View>

            <View style={styles.activityItem}>
              <Text style={styles.activityText}>Pago recibido: $150,000</Text>
              <Text style={styles.activityTime}>Hace 2 días</Text>
            </View>
          </Card.Content>
        </Card>

        <Card style={styles.quickActionsCard}>
          <Card.Content>
            <Title style={styles.sectionTitle}>Acciones Rápidas</Title>

            <View style={styles.actionsGrid}>
              <View style={styles.actionItem}>
                <Text style={styles.actionText}>Agregar Paciente</Text>
              </View>

              <View style={styles.actionItem}>
                <Text style={styles.actionText}>Agendar Cita</Text>
              </View>

              <View style={styles.actionItem}>
                <Text style={styles.actionText}>Generar Reporte</Text>
              </View>

              <View style={styles.actionItem}>
                <Text style={styles.actionText}>Gestionar Usuarios</Text>
              </View>
            </View>
          </Card.Content>
        </Card>
      </Surface>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.light,
  },
  surface: {
    margin: 16,
    padding: 16,
    borderRadius: 12,
    backgroundColor: COLORS.white,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: COLORS.textPrimary,
    marginBottom: 20,
    textAlign: 'center',
  },
  statsGrid: {
    marginBottom: 20,
  },
  statCard: {
    marginBottom: 12,
    borderLeftWidth: 4,
  },
  statValue: {
    fontSize: 28,
    fontWeight: 'bold',
  },
  statTitle: {
    fontSize: 16,
    color: COLORS.textPrimary,
    marginTop: 4,
  },
  statSubtitle: {
    fontSize: 14,
    color: COLORS.textSecondary,
  },
  recentActivityCard: {
    marginBottom: 16,
  },
  quickActionsCard: {
    marginBottom: 16,
  },
  sectionTitle: {
    fontSize: 18,
    color: COLORS.textPrimary,
    marginBottom: 12,
  },
  activityItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 8,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.light,
  },
  activityText: {
    fontSize: 14,
    color: COLORS.textPrimary,
    flex: 1,
  },
  activityTime: {
    fontSize: 12,
    color: COLORS.textSecondary,
  },
  actionsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  actionItem: {
    width: '48%',
    backgroundColor: COLORS.light,
    padding: 16,
    borderRadius: 8,
    marginBottom: 12,
    alignItems: 'center',
  },
  actionText: {
    fontSize: 14,
    color: COLORS.primary,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: COLORS.light,
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
    color: COLORS.textSecondary,
  },
});

export default AdminDashboardScreen;