import React, { useState } from 'react';
import { View, StyleSheet, Alert, ScrollView, Image } from 'react-native';
import { TextInput, Button, Text, Surface, RadioButton } from 'react-native-paper';
import { useAuth } from '../../contexts/AuthContext';
import { COLORS } from '../../utils/constants';

const RegisterScreen = ({ navigation }) => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    documento: '',
    telefono: '',
    direccion: '',
    fecha_nacimiento: '',
    genero: '',
  });
  const { register, isLoading } = useAuth();

  const updateFormData = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleRegister = async () => {
    const requiredFields = ['name', 'email', 'password', 'documento'];
    const missingFields = requiredFields.filter(field => !formData[field]);

    if (missingFields.length > 0) {
      Alert.alert('Error', `Please fill in: ${missingFields.join(', ')}`);
      return;
    }

    const result = await register(formData);
    if (result.success) {
      // Navigation will be handled by the app's navigation logic
    } else {
      Alert.alert('Registration Failed', result.error);
    }
  };

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.contentContainer}>
      <Surface style={styles.surface} elevation={4}>
        <Image source={require('../../../assets/mapu.png')} style={styles.logo} />
        <Text style={styles.title}>Crear Cuenta MAPU</Text>
        <Text style={styles.subtitle}>Únete a nuestro sistema de salud</Text>

        <TextInput
          label="Nombre Completo"
          value={formData.name}
          onChangeText={(value) => updateFormData('name', value)}
          mode="outlined"
          style={styles.input}
          theme={{ colors: { primary: COLORS.primary } }}
        />

        <TextInput
          label="Correo Electrónico"
          value={formData.email}
          onChangeText={(value) => updateFormData('email', value)}
          mode="outlined"
          keyboardType="email-address"
          autoCapitalize="none"
          style={styles.input}
          theme={{ colors: { primary: COLORS.primary } }}
        />

        <TextInput
          label="Contraseña"
          value={formData.password}
          onChangeText={(value) => updateFormData('password', value)}
          mode="outlined"
          secureTextEntry
          style={styles.input}
          theme={{ colors: { primary: COLORS.primary } }}
        />

        <TextInput
          label="Número de Documento"
          value={formData.documento}
          onChangeText={(value) => updateFormData('documento', value)}
          mode="outlined"
          style={styles.input}
          theme={{ colors: { primary: COLORS.primary } }}
        />

        <TextInput
          label="Número de Teléfono"
          value={formData.telefono}
          onChangeText={(value) => updateFormData('telefono', value)}
          mode="outlined"
          keyboardType="phone-pad"
          style={styles.input}
          theme={{ colors: { primary: COLORS.primary } }}
        />

        <TextInput
          label="Dirección"
          value={formData.direccion}
          onChangeText={(value) => updateFormData('direccion', value)}
          mode="outlined"
          multiline
          numberOfLines={2}
          style={styles.input}
          theme={{ colors: { primary: COLORS.primary } }}
        />

        <TextInput
          label="Fecha de Nacimiento (AAAA-MM-DD)"
          value={formData.fecha_nacimiento}
          onChangeText={(value) => updateFormData('fecha_nacimiento', value)}
          mode="outlined"
          placeholder="1990-01-01"
          style={styles.input}
          theme={{ colors: { primary: COLORS.primary } }}
        />

        <Text style={styles.label}>Género</Text>
        <RadioButton.Group
          onValueChange={(value) => updateFormData('genero', value)}
          value={formData.genero}
        >
          <View style={styles.radioContainer}>
            <RadioButton value="M" color={COLORS.primary} />
            <Text style={styles.radioLabel}>Masculino</Text>
          </View>
          <View style={styles.radioContainer}>
            <RadioButton value="F" color={COLORS.primary} />
            <Text style={styles.radioLabel}>Femenino</Text>
          </View>
          <View style={styles.radioContainer}>
            <RadioButton value="O" color={COLORS.primary} />
            <Text style={styles.radioLabel}>Otro</Text>
          </View>
        </RadioButton.Group>

        <Button
          mode="contained"
          onPress={handleRegister}
          loading={isLoading}
          disabled={isLoading}
          style={styles.button}
          buttonColor={COLORS.primary}
        >
          {isLoading ? 'Registrando...' : 'Registrarse'}
        </Button>

        <Button
          mode="text"
          onPress={() => navigation.navigate('Login')}
          style={styles.linkButton}
          textColor={COLORS.secondary}
        >
          ¿Ya tienes cuenta? Inicia Sesión
        </Button>
      </Surface>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.light,
  },
  contentContainer: {
    padding: 20,
    paddingBottom: 40,
  },
  surface: {
    padding: 24,
    borderRadius: 12,
    backgroundColor: COLORS.white,
  },
  logo: {
    width: 60,
    height: 60,
    alignSelf: 'center',
    marginBottom: 16,
  },
  title: {
    fontSize: 22,
    fontWeight: 'bold',
    textAlign: 'center',
    color: COLORS.textPrimary,
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 14,
    textAlign: 'center',
    color: COLORS.textSecondary,
    marginBottom: 20,
  },
  input: {
    marginBottom: 12,
  },
  label: {
    fontSize: 16,
    color: COLORS.textPrimary,
    marginBottom: 8,
    marginTop: 8,
  },
  radioContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  radioLabel: {
    fontSize: 16,
    color: COLORS.textPrimary,
    marginLeft: 8,
  },
  button: {
    marginTop: 16,
    marginBottom: 16,
  },
  linkButton: {
    marginTop: 8,
  },
});

export default RegisterScreen;