import React, { useState } from 'react';
import { View, StyleSheet, Alert, Image, ScrollView } from 'react-native';
import { TextInput, Button, Text, Surface, Card } from 'react-native-paper';
import { useAuth } from '../../contexts/AuthContext';
import { useToast } from '../../contexts/ToastContext';
import { COLORS, TEST_USERS } from '../../utils/constants';

const LoginScreen = ({ navigation }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const { login, isLoading } = useAuth();
  const { showSuccess, showError } = useToast();

  const handleLogin = async () => {
    if (!email || !password) {
      showError('Por favor complete todos los campos');
      return;
    }

    const result = await login(email, password);
    if (result.success) {
      showSuccess('¡Bienvenido a MAPU!');
      // Navigation will be handled by the app's navigation logic
    } else {
      let errorMessage = 'Error de inicio de sesión';
      if (result.error.includes('Network Error') || result.error.includes('timeout')) {
        errorMessage = 'Error de conexión. Verifique su conexión a internet.';
      } else if (result.error.includes('401')) {
        errorMessage = 'Credenciales incorrectas. Verifique su email y contraseña.';
      } else if (result.error.includes('500')) {
        errorMessage = 'Error del servidor. Intente nuevamente más tarde.';
      }
      showError(errorMessage);
    }
  };

  const fillTestCredentials = (userType) => {
    const user = TEST_USERS[userType];
    if (user) {
      setEmail(user.email);
      setPassword(user.password);
    }
  };

  return (
    <View style={styles.container}>
      <Surface style={styles.surface} elevation={4}>
        <Image source={{ uri: 'https://via.placeholder.com/80x80/0070C9/FFFFFF?text=MAPU' }} style={styles.logo} />
        <Text style={styles.title}>Bienvenido a MAPU</Text>
        <Text style={styles.subtitle}>Sistema de Gestión Médica</Text>

        <TextInput
          label="Correo electrónico"
          value={email}
          onChangeText={setEmail}
          mode="outlined"
          keyboardType="email-address"
          autoCapitalize="none"
          style={styles.input}
          theme={{ colors: { primary: COLORS.primary } }}
        />

        <TextInput
          label="Contraseña"
          value={password}
          onChangeText={setPassword}
          mode="outlined"
          secureTextEntry
          style={styles.input}
          theme={{ colors: { primary: COLORS.primary } }}
        />

        <Button
          mode="contained"
          onPress={handleLogin}
          loading={isLoading}
          disabled={isLoading}
          style={styles.button}
          buttonColor={COLORS.primary}
        >
          {isLoading ? 'Iniciando sesión...' : 'Iniciar Sesión'}
        </Button>

        <Button
          mode="text"
          onPress={() => navigation.navigate('Register')}
          style={styles.linkButton}
          textColor={COLORS.secondary}
        >
          ¿No tienes cuenta? Regístrate
        </Button>

        {/* Test Credentials Section */}
        <Card style={styles.testCard}>
          <Card.Content>
            <Text style={styles.testTitle}>🔧 Credenciales de Prueba</Text>
            <View style={styles.testButtonsContainer}>
              <Button
                mode="outlined"
                onPress={() => fillTestCredentials('DOCTOR')}
                style={styles.testButton}
                labelStyle={styles.testButtonText}
              >
                👨‍⚕️ Doctor
              </Button>
              <Button
                mode="outlined"
                onPress={() => fillTestCredentials('PACIENTE_1')}
                style={styles.testButton}
                labelStyle={styles.testButtonText}
              >
                👤 Paciente
              </Button>
              <Button
                mode="outlined"
                onPress={() => fillTestCredentials('ADMIN')}
                style={styles.testButton}
                labelStyle={styles.testButtonText}
              >
                👑 Admin
              </Button>
            </View>
          </Card.Content>
        </Card>
      </Surface>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    padding: 20,
    backgroundColor: COLORS.light,
  },
  surface: {
    padding: 24,
    borderRadius: 12,
    backgroundColor: COLORS.white,
  },
  logo: {
    width: 80,
    height: 80,
    alignSelf: 'center',
    marginBottom: 16,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    textAlign: 'center',
    color: COLORS.textPrimary,
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 16,
    textAlign: 'center',
    color: COLORS.textSecondary,
    marginBottom: 24,
  },
  input: {
    marginBottom: 16,
  },
  button: {
    marginTop: 8,
    marginBottom: 16,
  },
  linkButton: {
    marginTop: 8,
  },
  testCard: {
    marginTop: 20,
    backgroundColor: COLORS.light,
  },
  testTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: COLORS.textPrimary,
    textAlign: 'center',
    marginBottom: 12,
  },
  testButtonsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    flexWrap: 'wrap',
  },
  testButton: {
    flex: 1,
    marginHorizontal: 4,
    marginVertical: 4,
    minWidth: 80,
  },
  testButtonText: {
    fontSize: 12,
  },
});

export default LoginScreen;