import React, { useState, useEffect } from 'react';
import { View, StyleSheet, FlatList, ScrollView } from 'react-native';
import { Text, Surface, Card, Button, TextInput, FAB, Portal, Modal, Chip } from 'react-native-paper';
import { COLORS } from '../../utils/constants';

const DoctorPrescriptionsScreen = () => {
  const [prescriptions, setPrescriptions] = useState([]);
  const [modalVisible, setModalVisible] = useState(false);
  const [medicines, setMedicines] = useState([]);
  const [newPrescription, setNewPrescription] = useState({
    paciente_id: '',
    medicamentos: [],
    instrucciones: '',
    duracion: '',
  });
  const [currentMedicine, setCurrentMedicine] = useState({
    medicamento_id: '',
    dosis: '',
    frecuencia: '',
    duracion: '',
  });

  useEffect(() => {
    // TODO: Fetch prescriptions from API
    // Mock data for now
    setPrescriptions([
      {
        id: 1,
        paciente: 'Juan Pérez',
        fecha: '2025-09-15',
        medicamentos: [
          { nombre: 'Amoxicillin', dosis: '500mg', frecuencia: '3 times daily', duracion: '7 days' },
          { nombre: 'Ibuprofen', dosis: '400mg', frecuencia: 'As needed', duracion: '5 days' },
        ],
        instrucciones: 'Take with food. Complete the full course.',
        estado: 'activa',
      },
      {
        id: 2,
        paciente: 'María García',
        fecha: '2025-09-10',
        medicamentos: [
          { nombre: 'Lisinopril', dosis: '10mg', frecuencia: 'Once daily', duracion: 'Ongoing' },
        ],
        instrucciones: 'Monitor blood pressure regularly.',
        estado: 'activa',
      },
    ]);

    // Mock medicines
    setMedicines([
      { id: 1, nombre: 'Amoxicillin' },
      { id: 2, nombre: 'Ibuprofen' },
      { id: 3, nombre: 'Lisinopril' },
      { id: 4, nombre: 'Paracetamol' },
    ]);
  }, []);

  const addMedicineToPrescription = () => {
    if (!currentMedicine.medicamento_id || !currentMedicine.dosis) {
      alert('Please fill in medicine and dosage');
      return;
    }

    const medicine = medicines.find(m => m.id === parseInt(currentMedicine.medicamento_id));
    const medicineWithDetails = {
      ...medicine,
      dosis: currentMedicine.dosis,
      frecuencia: currentMedicine.frecuencia,
      duracion: currentMedicine.duracion,
    };

    setNewPrescription(prev => ({
      ...prev,
      medicamentos: [...prev.medicamentos, medicineWithDetails],
    }));

    setCurrentMedicine({ medicamento_id: '', dosis: '', frecuencia: '', duracion: '' });
  };

  const removeMedicine = (index) => {
    setNewPrescription(prev => ({
      ...prev,
      medicamentos: prev.medicamentos.filter((_, i) => i !== index),
    }));
  };

  const handleCreatePrescription = () => {
    if (!newPrescription.paciente_id || newPrescription.medicamentos.length === 0) {
      alert('Please select patient and add at least one medicine');
      return;
    }

    // TODO: API call to create prescription
    const prescription = {
      id: Date.now(),
      paciente: 'Patient Name', // Would get from API
      fecha: new Date().toISOString().split('T')[0],
      medicamentos: newPrescription.medicamentos,
      instrucciones: newPrescription.instrucciones,
      estado: 'activa',
    };

    setPrescriptions(prev => [prescription, ...prev]);
    setNewPrescription({
      paciente_id: '',
      medicamentos: [],
      instrucciones: '',
      duracion: '',
    });
    setModalVisible(false);
  };

  const renderPrescription = ({ item }) => (
    <Card style={styles.card}>
      <Card.Content>
        <View style={styles.prescriptionHeader}>
          <Text style={styles.patientName}>{item.paciente}</Text>
          <Chip
            mode="outlined"
            style={[styles.statusChip, { borderColor: COLORS.secondary }]}
            textStyle={{ color: COLORS.secondary }}
          >
            {item.estado}
          </Chip>
        </View>

        <Text style={styles.date}>{item.fecha}</Text>

        <Text style={styles.medicinesTitle}>Medicines:</Text>
        {item.medicamentos.map((med, index) => (
          <Text key={index} style={styles.medicine}>
            • {med.nombre} - {med.dosis} - {med.frecuencia} - {med.duracion}
          </Text>
        ))}

        <Text style={styles.instructions}>Instructions: {item.instrucciones}</Text>
      </Card.Content>
    </Card>
  );

  return (
    <View style={styles.container}>
      <Surface style={styles.surface} elevation={4}>
        <Text style={styles.title}>Recetas Médicas</Text>

        {prescriptions.length === 0 ? (
          <Text style={styles.emptyText}>No se encontraron recetas</Text>
        ) : (
          <FlatList
            data={prescriptions}
            renderItem={renderPrescription}
            keyExtractor={(item) => item.id.toString()}
            showsVerticalScrollIndicator={false}
          />
        )}
      </Surface>

      <FAB
        icon="plus"
        style={styles.fab}
        onPress={() => setModalVisible(true)}
      />

      <Portal>
        <Modal
          visible={modalVisible}
          onDismiss={() => setModalVisible(false)}
          contentContainerStyle={styles.modalContainer}
        >
          <ScrollView style={styles.modalContent}>
            <Text style={styles.modalTitle}>Create Prescription</Text>

            <TextInput
              label="Patient ID"
              value={newPrescription.paciente_id}
              onChangeText={(value) => setNewPrescription(prev => ({ ...prev, paciente_id: value }))}
              mode="outlined"
              placeholder="Enter patient ID"
              style={styles.input}
            />

            <Text style={styles.sectionTitle}>Add Medicine</Text>

            <TextInput
              label="Medicine"
              value={currentMedicine.medicamento_id}
              onChangeText={(value) => setCurrentMedicine(prev => ({ ...prev, medicamento_id: value }))}
              mode="outlined"
              placeholder="Select medicine ID"
              style={styles.input}
            />

            <TextInput
              label="Dosage"
              value={currentMedicine.dosis}
              onChangeText={(value) => setCurrentMedicine(prev => ({ ...prev, dosis: value }))}
              mode="outlined"
              placeholder="e.g., 500mg"
              style={styles.input}
            />

            <TextInput
              label="Frequency"
              value={currentMedicine.frecuencia}
              onChangeText={(value) => setCurrentMedicine(prev => ({ ...prev, frecuencia: value }))}
              mode="outlined"
              placeholder="e.g., 3 times daily"
              style={styles.input}
            />

            <TextInput
              label="Duration"
              value={currentMedicine.duracion}
              onChangeText={(value) => setCurrentMedicine(prev => ({ ...prev, duracion: value }))}
              mode="outlined"
              placeholder="e.g., 7 days"
              style={styles.input}
            />

            <Button
              mode="outlined"
              onPress={addMedicineToPrescription}
              style={styles.addButton}
            >
              Add Medicine
            </Button>

            {newPrescription.medicamentos.length > 0 && (
              <View style={styles.medicinesList}>
                <Text style={styles.medicinesTitle}>Medicines in prescription:</Text>
                {newPrescription.medicamentos.map((med, index) => (
                  <View key={index} style={styles.medicineItem}>
                    <Text style={styles.medicineText}>
                      {med.nombre} - {med.dosis} - {med.frecuencia}
                    </Text>
                    <Button
                      mode="text"
                      onPress={() => removeMedicine(index)}
                      textColor="#F44336"
                    >
                      Remove
                    </Button>
                  </View>
                ))}
              </View>
            )}

            <TextInput
              label="Instructions"
              value={newPrescription.instrucciones}
              onChangeText={(value) => setNewPrescription(prev => ({ ...prev, instrucciones: value }))}
              mode="outlined"
              multiline
              numberOfLines={3}
              style={styles.input}
            />

            <View style={styles.modalButtons}>
              <Button
                mode="outlined"
                onPress={() => setModalVisible(false)}
                style={styles.cancelButton}
              >
                Cancel
              </Button>
              <Button
                mode="contained"
                onPress={handleCreatePrescription}
                style={styles.createButton}
                buttonColor={COLORS.primary}
              >
                Create Prescription
              </Button>
            </View>
          </ScrollView>
        </Modal>
      </Portal>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.light,
  },
  surface: {
    flex: 1,
    margin: 16,
    padding: 16,
    borderRadius: 12,
    backgroundColor: COLORS.white,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: COLORS.textPrimary,
    marginBottom: 16,
    textAlign: 'center',
  },
  card: {
    marginBottom: 12,
  },
  prescriptionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 4,
  },
  patientName: {
    fontSize: 18,
    fontWeight: 'bold',
    color: COLORS.primary,
  },
  statusChip: {
    backgroundColor: 'transparent',
  },
  date: {
    fontSize: 14,
    color: COLORS.textSecondary,
    marginBottom: 8,
  },
  medicinesTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: COLORS.textPrimary,
    marginBottom: 4,
  },
  medicine: {
    fontSize: 14,
    color: COLORS.textSecondary,
    marginBottom: 2,
  },
  instructions: {
    fontSize: 14,
    color: COLORS.textPrimary,
    fontStyle: 'italic',
    marginTop: 8,
  },
  emptyText: {
    textAlign: 'center',
    fontSize: 16,
    color: COLORS.textSecondary,
    marginTop: 32,
  },
  fab: {
    position: 'absolute',
    margin: 16,
    right: 0,
    bottom: 0,
    backgroundColor: COLORS.primary,
  },
  modalContainer: {
    backgroundColor: COLORS.white,
    margin: 20,
    borderRadius: 12,
    maxHeight: '80%',
  },
  modalContent: {
    padding: 20,
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: COLORS.textPrimary,
    marginBottom: 16,
    textAlign: 'center',
  },
  input: {
    marginBottom: 12,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: COLORS.textPrimary,
    marginBottom: 8,
    marginTop: 8,
  },
  addButton: {
    marginBottom: 16,
  },
  medicinesList: {
    marginBottom: 16,
  },
  medicineItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 8,
    backgroundColor: COLORS.light,
    borderRadius: 8,
    marginBottom: 8,
  },
  medicineText: {
    fontSize: 14,
    color: COLORS.textPrimary,
    flex: 1,
  },
  modalButtons: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 16,
  },
  cancelButton: {
    flex: 1,
    marginRight: 8,
  },
  createButton: {
    flex: 1,
    marginLeft: 8,
  },
});

export default DoctorPrescriptionsScreen;