import React, { useState, useEffect } from 'react';
import { View, StyleSheet, FlatList, TouchableOpacity, ScrollView } from 'react-native';
import { Text, Surface, Card, Button, TextInput, FAB, Portal, Modal, Chip } from 'react-native-paper';
import { COLORS } from '../../utils/constants';

const DoctorMedicalRecordsScreen = () => {
  const [records, setRecords] = useState([]);
  const [modalVisible, setModalVisible] = useState(false);
  const [selectedPatient, setSelectedPatient] = useState(null);
  const [newRecord, setNewRecord] = useState({
    paciente_id: '',
    diagnostico: '',
    tratamiento: '',
    notas: '',
  });

  useEffect(() => {
    // TODO: Fetch medical records from API
    // Mock data for now
    setRecords([
      {
        id: 1,
        paciente: 'Juan Pérez',
        fecha: '2025-09-15',
        diagnostico: 'Respiratory infection',
        tratamiento: 'Antibiotics for 7 days',
        notas: 'Patient responded well to treatment',
        medico: 'Dr. Current User',
      },
      {
        id: 2,
        paciente: 'María García',
        fecha: '2025-09-10',
        diagnostico: 'Hypertension',
        tratamiento: 'ACE inhibitors, lifestyle changes',
        notas: 'Blood pressure monitoring required',
        medico: 'Dr. Current User',
      },
    ]);
  }, []);

  const patients = [
    { id: 1, name: 'Juan Pérez' },
    { id: 2, name: 'María García' },
    { id: 3, name: 'Carlos Rodríguez' },
  ];

  const handleCreateRecord = () => {
    if (!newRecord.paciente_id || !newRecord.diagnostico) {
      alert('Please fill in required fields');
      return;
    }

    // TODO: API call to create record
    const record = {
      id: Date.now(),
      paciente: patients.find(p => p.id === parseInt(newRecord.paciente_id))?.name || 'Unknown',
      fecha: new Date().toISOString().split('T')[0],
      diagnostico: newRecord.diagnostico,
      tratamiento: newRecord.tratamiento,
      notas: newRecord.notas,
      medico: 'Dr. Current User',
    };

    setRecords(prev => [record, ...prev]);
    setNewRecord({ paciente_id: '', diagnostico: '', tratamiento: '', notas: '' });
    setModalVisible(false);
  };

  const renderRecord = ({ item }) => (
    <Card style={styles.card}>
      <Card.Content>
        <View style={styles.recordHeader}>
          <Text style={styles.patientName}>{item.paciente}</Text>
          <Text style={styles.date}>{item.fecha}</Text>
        </View>

        <Text style={styles.diagnosis}>Diagnosis: {item.diagnostico}</Text>
        <Text style={styles.treatment}>Treatment: {item.tratamiento}</Text>
        <Text style={styles.notes}>Notes: {item.notas}</Text>
        <Text style={styles.doctor}>By: {item.medico}</Text>
      </Card.Content>
    </Card>
  );

  return (
    <View style={styles.container}>
      <Surface style={styles.surface} elevation={4}>
        <Text style={styles.title}>Registros Médicos</Text>

        {records.length === 0 ? (
          <Text style={styles.emptyText}>No se encontraron registros médicos</Text>
        ) : (
          <FlatList
            data={records}
            renderItem={renderRecord}
            keyExtractor={(item) => item.id.toString()}
            showsVerticalScrollIndicator={false}
          />
        )}
      </Surface>

      <FAB
        icon="plus"
        style={styles.fab}
        onPress={() => setModalVisible(true)}
      />

      <Portal>
        <Modal
          visible={modalVisible}
          onDismiss={() => setModalVisible(false)}
          contentContainerStyle={styles.modalContainer}
        >
          <ScrollView style={styles.modalContent}>
            <Text style={styles.modalTitle}>Create Medical Record</Text>

            <TextInput
              label="Patient"
              value={newRecord.paciente_id}
              onChangeText={(value) => setNewRecord(prev => ({ ...prev, paciente_id: value }))}
              mode="outlined"
              placeholder="Select patient ID"
              style={styles.input}
            />

            <TextInput
              label="Diagnosis *"
              value={newRecord.diagnostico}
              onChangeText={(value) => setNewRecord(prev => ({ ...prev, diagnostico: value }))}
              mode="outlined"
              multiline
              numberOfLines={2}
              style={styles.input}
            />

            <TextInput
              label="Treatment"
              value={newRecord.tratamiento}
              onChangeText={(value) => setNewRecord(prev => ({ ...prev, tratamiento: value }))}
              mode="outlined"
              multiline
              numberOfLines={2}
              style={styles.input}
            />

            <TextInput
              label="Notes"
              value={newRecord.notas}
              onChangeText={(value) => setNewRecord(prev => ({ ...prev, notas: value }))}
              mode="outlined"
              multiline
              numberOfLines={3}
              style={styles.input}
            />

            <View style={styles.modalButtons}>
              <Button
                mode="outlined"
                onPress={() => setModalVisible(false)}
                style={styles.cancelButton}
              >
                Cancel
              </Button>
              <Button
                mode="contained"
                onPress={handleCreateRecord}
                style={styles.createButton}
                buttonColor={COLORS.primary}
              >
                Create Record
              </Button>
            </View>
          </ScrollView>
        </Modal>
      </Portal>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.light,
  },
  surface: {
    flex: 1,
    margin: 16,
    padding: 16,
    borderRadius: 12,
    backgroundColor: COLORS.white,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: COLORS.textPrimary,
    marginBottom: 16,
    textAlign: 'center',
  },
  card: {
    marginBottom: 12,
  },
  recordHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  patientName: {
    fontSize: 18,
    fontWeight: 'bold',
    color: COLORS.primary,
  },
  date: {
    fontSize: 14,
    color: COLORS.textSecondary,
  },
  diagnosis: {
    fontSize: 16,
    color: COLORS.textPrimary,
    marginBottom: 4,
  },
  treatment: {
    fontSize: 14,
    color: COLORS.textSecondary,
    marginBottom: 4,
  },
  notes: {
    fontSize: 14,
    color: COLORS.textPrimary,
    fontStyle: 'italic',
    marginBottom: 8,
  },
  doctor: {
    fontSize: 12,
    color: COLORS.textSecondary,
  },
  emptyText: {
    textAlign: 'center',
    fontSize: 16,
    color: COLORS.textSecondary,
    marginTop: 32,
  },
  fab: {
    position: 'absolute',
    margin: 16,
    right: 0,
    bottom: 0,
    backgroundColor: COLORS.primary,
  },
  modalContainer: {
    backgroundColor: COLORS.white,
    margin: 20,
    borderRadius: 12,
  },
  modalContent: {
    padding: 20,
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: COLORS.textPrimary,
    marginBottom: 16,
    textAlign: 'center',
  },
  input: {
    marginBottom: 12,
  },
  modalButtons: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 16,
  },
  cancelButton: {
    flex: 1,
    marginRight: 8,
  },
  createButton: {
    flex: 1,
    marginLeft: 8,
  },
});

export default DoctorMedicalRecordsScreen;