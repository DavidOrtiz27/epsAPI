import React, { useState, useEffect } from 'react';
import { View, StyleSheet, FlatList, TouchableOpacity } from 'react-native';
import { Text, Surface, Card, Button, Chip, FAB } from 'react-native-paper';
import { COLORS } from '../../utils/constants';

const DoctorAppointmentsScreen = () => {
  const [appointments, setAppointments] = useState([]);

  useEffect(() => {
    // TODO: Fetch appointments from API
    // Mock data for now
    setAppointments([
      {
        id: 1,
        paciente: 'Juan Pérez',
        fecha: '2025-09-20',
        hora: '10:00',
        motivo: 'Consulta general',
        estado: 'pendiente',
        tipo: 'consulta',
      },
      {
        id: 2,
        paciente: 'María García',
        fecha: '2025-09-20',
        hora: '11:30',
        motivo: 'Seguimiento hipertensión',
        estado: 'confirmada',
        tipo: 'seguimiento',
      },
      {
        id: 3,
        paciente: 'Carlos Rodríguez',
        fecha: '2025-09-18',
        hora: '09:00',
        motivo: 'Examen físico anual',
        estado: 'completada',
        tipo: 'examen',
      },
    ]);
  }, []);

  const getStatusColor = (estado) => {
    switch (estado) {
      case 'pendiente': return COLORS.secondary;
      case 'confirmada': return COLORS.primary;
      case 'completada': return '#4CAF50';
      case 'cancelada': return '#F44336';
      default: return COLORS.textSecondary;
    }
  };

  const updateAppointmentStatus = (appointmentId, newStatus) => {
    setAppointments(prev =>
      prev.map(apt =>
        apt.id === appointmentId ? { ...apt, estado: newStatus } : apt
      )
    );
    // TODO: API call to update status
  };

  const renderAppointment = ({ item }) => (
    <Card style={styles.card}>
      <Card.Content>
        <View style={styles.appointmentHeader}>
          <Text style={styles.date}>{item.fecha} at {item.hora}</Text>
          <Chip
            mode="outlined"
            style={[styles.statusChip, { borderColor: getStatusColor(item.estado) }]}
            textStyle={{ color: getStatusColor(item.estado) }}
          >
            {item.estado}
          </Chip>
        </View>

        <Text style={styles.patientName}>{item.paciente}</Text>
        <Text style={styles.reason}>Reason: {item.motivo}</Text>
        <Text style={styles.type}>Type: {item.tipo}</Text>

        {item.estado === 'pendiente' && (
          <View style={styles.buttonContainer}>
            <Button
              mode="contained"
              onPress={() => updateAppointmentStatus(item.id, 'confirmada')}
              style={styles.confirmButton}
              buttonColor={COLORS.primary}
            >
              Confirm
            </Button>
            <Button
              mode="outlined"
              onPress={() => updateAppointmentStatus(item.id, 'cancelada')}
              style={styles.cancelButton}
            >
              Cancel
            </Button>
          </View>
        )}

        {item.estado === 'confirmada' && (
          <View style={styles.buttonContainer}>
            <Button
              mode="contained"
              onPress={() => {/* TODO: Start consultation */}}
              style={styles.startButton}
              buttonColor={COLORS.secondary}
            >
              Start Consultation
            </Button>
          </View>
        )}

        {item.estado === 'completada' && (
          <View style={styles.buttonContainer}>
            <Button
              mode="outlined"
              onPress={() => {/* TODO: View consultation details */}}
              style={styles.viewButton}
            >
              View Details
            </Button>
          </View>
        )}
      </Card.Content>
    </Card>
  );

  return (
    <View style={styles.container}>
      <Surface style={styles.surface} elevation={4}>
        <Text style={styles.title}>Mis Citas</Text>

        {appointments.length === 0 ? (
          <Text style={styles.emptyText}>No hay citas programadas</Text>
        ) : (
          <FlatList
            data={appointments}
            renderItem={renderAppointment}
            keyExtractor={(item) => item.id.toString()}
            showsVerticalScrollIndicator={false}
          />
        )}
      </Surface>

      <FAB
        icon="plus"
        style={styles.fab}
        onPress={() => {/* TODO: Navigate to schedule new appointment */}}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.light,
  },
  surface: {
    flex: 1,
    margin: 16,
    padding: 16,
    borderRadius: 12,
    backgroundColor: COLORS.white,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: COLORS.textPrimary,
    marginBottom: 16,
    textAlign: 'center',
  },
  card: {
    marginBottom: 12,
  },
  appointmentHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  date: {
    fontSize: 16,
    fontWeight: 'bold',
    color: COLORS.primary,
  },
  statusChip: {
    backgroundColor: 'transparent',
  },
  patientName: {
    fontSize: 18,
    fontWeight: 'bold',
    color: COLORS.textPrimary,
    marginBottom: 4,
  },
  reason: {
    fontSize: 14,
    color: COLORS.textSecondary,
    marginBottom: 4,
  },
  type: {
    fontSize: 14,
    color: COLORS.textPrimary,
    marginBottom: 12,
  },
  buttonContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  confirmButton: {
    flex: 1,
    marginRight: 8,
  },
  cancelButton: {
    flex: 1,
    marginLeft: 8,
  },
  startButton: {
    flex: 1,
  },
  viewButton: {
    flex: 1,
  },
  emptyText: {
    textAlign: 'center',
    fontSize: 16,
    color: COLORS.textSecondary,
    marginTop: 32,
  },
  fab: {
    position: 'absolute',
    margin: 16,
    right: 0,
    bottom: 0,
    backgroundColor: COLORS.primary,
  },
});

export default DoctorAppointmentsScreen;