import React, { useState, useEffect } from 'react';
import { View, StyleSheet, FlatList, TouchableOpacity, Alert } from 'react-native';
import { Text, Surface, Card, Searchbar, Chip, ActivityIndicator } from 'react-native-paper';
import { COLORS, cleanApiData } from '../../utils/constants';
import { doctorAPI } from '../../services/api';

const DoctorPatientsScreen = ({ navigation }) => {
  const [patients, setPatients] = useState([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [filteredPatients, setFilteredPatients] = useState([]);

  useEffect(() => {
    loadPatients();
  }, []);

  const loadPatients = async () => {
    try {
      setLoading(true);
      const response = await doctorAPI.getPatients();
      const patientsData = cleanApiData(response.data || []);
      setPatients(patientsData);
      setFilteredPatients(patientsData);
    } catch (error) {
      console.error('Error loading patients:', error);
      Alert.alert('Error', 'No se pudieron cargar los pacientes. Verifique su conexión a internet.');
      setPatients([]);
      setFilteredPatients([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (searchQuery) {
      const filtered = patients.filter(patient =>
        patient.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        patient.documento.includes(searchQuery)
      );
      setFilteredPatients(filtered);
    } else {
      setFilteredPatients(patients);
    }
  }, [searchQuery, patients]);

  const renderPatient = ({ item }) => (
    <TouchableOpacity onPress={() => {/* TODO: Navigate to patient details */}}>
      <Card style={styles.card}>
        <Card.Content>
          <View style={styles.patientHeader}>
            <Text style={styles.patientName}>{item.name}</Text>
            <Chip
              mode="outlined"
              style={[styles.statusChip, {
                borderColor: item.estado === 'activo' ? COLORS.secondary : COLORS.textSecondary
              }]}
              textStyle={{
                color: item.estado === 'activo' ? COLORS.secondary : COLORS.textSecondary
              }}
            >
              {item.estado}
            </Chip>
          </View>

          <Text style={styles.patientInfo}>ID: {item.documento}</Text>
          <Text style={styles.patientInfo}>Phone: {item.telefono}</Text>
          <Text style={styles.patientInfo}>Last Visit: {item.ultima_consulta}</Text>

          <View style={styles.actionButtons}>
            <TouchableOpacity
              style={[styles.actionButton, { backgroundColor: COLORS.primary }]}
              onPress={() => {/* TODO: View medical history */}}
            >
              <Text style={styles.actionButtonText}>View History</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.actionButton, { backgroundColor: COLORS.secondary }]}
              onPress={() => {/* TODO: Schedule appointment */}}
            >
              <Text style={styles.actionButtonText}>Schedule</Text>
            </TouchableOpacity>
          </View>
        </Card.Content>
      </Card>
    </TouchableOpacity>
  );

  return (
    <View style={styles.container}>
      <Surface style={styles.surface} elevation={4}>
        <Text style={styles.title}>Mis Pacientes</Text>

        <Searchbar
          placeholder="Buscar por nombre o ID"
          onChangeText={setSearchQuery}
          value={searchQuery}
          style={styles.searchbar}
        />

        {filteredPatients.length === 0 ? (
          <Text style={styles.emptyText}>No se encontraron pacientes</Text>
        ) : (
          <FlatList
            data={filteredPatients}
            renderItem={renderPatient}
            keyExtractor={(item) => item.id.toString()}
            showsVerticalScrollIndicator={false}
          />
        )}
      </Surface>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.light,
  },
  surface: {
    flex: 1,
    margin: 16,
    padding: 16,
    borderRadius: 12,
    backgroundColor: COLORS.white,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: COLORS.textPrimary,
    marginBottom: 16,
    textAlign: 'center',
  },
  searchbar: {
    marginBottom: 16,
  },
  card: {
    marginBottom: 12,
  },
  patientHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  patientName: {
    fontSize: 18,
    fontWeight: 'bold',
    color: COLORS.textPrimary,
    flex: 1,
  },
  statusChip: {
    backgroundColor: 'transparent',
  },
  patientInfo: {
    fontSize: 14,
    color: COLORS.textSecondary,
    marginBottom: 4,
  },
  actionButtons: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 12,
  },
  actionButton: {
    flex: 1,
    padding: 10,
    borderRadius: 8,
    marginHorizontal: 4,
    alignItems: 'center',
  },
  actionButtonText: {
    color: COLORS.white,
    fontWeight: 'bold',
  },
  emptyText: {
    textAlign: 'center',
    fontSize: 16,
    color: COLORS.textSecondary,
    marginTop: 32,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: COLORS.light,
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
    color: COLORS.textSecondary,
  },
});

export default DoctorPatientsScreen;