import React from 'react';
import { View, StyleSheet, ScrollView } from 'react-native';
import { Text, Surface, Card, Button, Avatar } from 'react-native-paper';
import { useAuth } from '../contexts/AuthContext';
import { COLORS } from '../utils/constants';

const HomeScreen = ({ navigation }) => {
  const { user } = useAuth();
  const userRole = user?.roles?.[0]?.name || 'Desconocido';

  const getRoleDisplayName = (role) => {
    switch (role) {
      case 'paciente': return 'Paciente';
      case 'doctor': return 'Doctor';
      case 'admin': return 'Administrador';
      case 'superadmin': return 'Super Administrador';
      default: return 'Usuario';
    }
  };

  const getWelcomeMessage = () => {
    const hour = new Date().getHours();
    if (hour < 12) return 'Buenos días';
    if (hour < 18) return 'Buenas tardes';
    return 'Buenas noches';
  };

  const quickActions = [
    {
      title: 'Mis Citas',
      subtitle: 'Ver y gestionar citas',
      icon: 'calendar',
      action: () => navigation.navigate('Appointments'),
      color: COLORS.primary,
    },
    {
      title: 'Mi Perfil',
      subtitle: 'Ver y editar información',
      icon: 'account',
      action: () => navigation.navigate('Profile'),
      color: COLORS.secondary,
    },
    {
      title: 'Historial Médico',
      subtitle: 'Ver registros médicos',
      icon: 'file-document',
      action: () => navigation.navigate('MedicalHistory'),
      color: '#4CAF50',
    },
    {
      title: 'Facturas',
      subtitle: 'Ver estado de pagos',
      icon: 'receipt',
      action: () => navigation.navigate('Bills'),
      color: '#FF9800',
    },
  ];

  return (
    <ScrollView style={styles.container}>
      <Surface style={styles.surface} elevation={4}>
        {/* Welcome Header */}
        <View style={styles.header}>
          <Avatar.Text
            size={60}
            label={user?.name?.charAt(0)?.toUpperCase() || 'U'}
            style={styles.avatar}
            color={COLORS.white}
          />
          <View style={styles.headerText}>
            <Text style={styles.welcomeMessage}>{getWelcomeMessage()}</Text>
            <Text style={styles.userName}>{user?.name || 'Usuario'}</Text>
            <Text style={styles.userRole}>{getRoleDisplayName(userRole)}</Text>
          </View>
        </View>

        {/* Quick Stats */}
        <Card style={styles.statsCard}>
          <Card.Content>
            <Text style={styles.statsTitle}>Resumen del Día</Text>
            <View style={styles.statsRow}>
              <View style={styles.statItem}>
                <Text style={styles.statNumber}>0</Text>
                <Text style={styles.statLabel}>Citas Hoy</Text>
              </View>
              <View style={styles.statItem}>
                <Text style={styles.statNumber}>0</Text>
                <Text style={styles.statLabel}>Pendientes</Text>
              </View>
              <View style={styles.statItem}>
                <Text style={styles.statNumber}>0</Text>
                <Text style={styles.statLabel}>Completadas</Text>
              </View>
            </View>
          </Card.Content>
        </Card>

        {/* Quick Actions */}
        <Text style={styles.sectionTitle}>Acciones Rápidas</Text>
        <View style={styles.actionsGrid}>
          {quickActions.map((action, index) => (
            <Card
              key={index}
              style={styles.actionCard}
              onPress={action.action}
            >
              <Card.Content style={styles.actionContent}>
                <View style={[styles.actionIcon, { backgroundColor: action.color }]}>
                  <Text style={styles.actionIconText}>
                    {action.icon === 'calendar' ? '📅' :
                     action.icon === 'account' ? '👤' :
                     action.icon === 'file-document' ? '📄' :
                     action.icon === 'receipt' ? '🧾' : '📱'}
                  </Text>
                </View>
                <View style={styles.actionText}>
                  <Text style={styles.actionTitle}>{action.title}</Text>
                  <Text style={styles.actionSubtitle}>{action.subtitle}</Text>
                </View>
              </Card.Content>
            </Card>
          ))}
        </View>

        {/* Recent Activity */}
        <Card style={styles.activityCard}>
          <Card.Content>
            <Text style={styles.sectionTitle}>Actividad Reciente</Text>
            <Text style={styles.noActivityText}>
              No hay actividad reciente para mostrar
            </Text>
            <Text style={styles.activityHint}>
              Tus actividades aparecerán aquí cuando uses la aplicación
            </Text>
          </Card.Content>
        </Card>

        {/* Motivational Message */}
        <Card style={styles.motivationCard}>
          <Card.Content>
            <Text style={styles.motivationText}>
              "Tu salud es tu mayor riqueza. MAPU está aquí para cuidarte."
            </Text>
          </Card.Content>
        </Card>
      </Surface>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.light,
  },
  surface: {
    margin: 16,
    padding: 16,
    borderRadius: 12,
    backgroundColor: COLORS.white,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 20,
    paddingBottom: 16,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.light,
  },
  avatar: {
    backgroundColor: COLORS.primary,
    marginRight: 16,
  },
  headerText: {
    flex: 1,
  },
  welcomeMessage: {
    fontSize: 16,
    color: COLORS.textSecondary,
  },
  userName: {
    fontSize: 22,
    fontWeight: 'bold',
    color: COLORS.textPrimary,
  },
  userRole: {
    fontSize: 14,
    color: COLORS.primary,
    fontWeight: '500',
  },
  statsCard: {
    marginBottom: 20,
  },
  statsTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: COLORS.textPrimary,
    marginBottom: 12,
  },
  statsRow: {
    flexDirection: 'row',
    justifyContent: 'space-around',
  },
  statItem: {
    alignItems: 'center',
  },
  statNumber: {
    fontSize: 24,
    fontWeight: 'bold',
    color: COLORS.primary,
  },
  statLabel: {
    fontSize: 12,
    color: COLORS.textSecondary,
    marginTop: 4,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: COLORS.textPrimary,
    marginBottom: 12,
    marginTop: 8,
  },
  actionsGrid: {
    marginBottom: 20,
  },
  actionCard: {
    marginBottom: 12,
    elevation: 2,
  },
  actionContent: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  actionIcon: {
    width: 50,
    height: 50,
    borderRadius: 25,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 16,
  },
  actionIconText: {
    fontSize: 20,
  },
  actionText: {
    flex: 1,
  },
  actionTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: COLORS.textPrimary,
  },
  actionSubtitle: {
    fontSize: 12,
    color: COLORS.textSecondary,
    marginTop: 2,
  },
  activityCard: {
    marginBottom: 16,
  },
  noActivityText: {
    fontSize: 14,
    color: COLORS.textSecondary,
    textAlign: 'center',
    marginBottom: 8,
  },
  activityHint: {
    fontSize: 12,
    color: COLORS.textSecondary,
    textAlign: 'center',
    fontStyle: 'italic',
  },
  motivationCard: {
    marginBottom: 16,
    backgroundColor: COLORS.primary + '10',
  },
  motivationText: {
    fontSize: 16,
    color: COLORS.primary,
    textAlign: 'center',
    fontStyle: 'italic',
  },
});

export default HomeScreen;